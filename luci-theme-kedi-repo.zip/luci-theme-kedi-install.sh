#!/bin/sh
# ============================================================================
#  luci-theme-kedi 1.0.0 — OpenWrt LuCI için mor Kedi teması (koyu / açık / otomatik)
#  Bootstrap temasından türetilmiştir (Apache-2.0); Kedi renkleri ve düzeni eklidir.
#
#  Kurulum:  sh luci-theme-kedi-install.sh            (temayı kurar ve etkinleştirir)
#            sh luci-theme-kedi-install.sh --no-activate   (kurar, etkinleştirmez)
#  Kaldırma: sh luci-theme-kedi-install.sh --remove   (eski temaya döner, dosyaları siler)
#  Seçim:    Sistem → Görünüm (System → Style) → Tema: Kedi
# ============================================================================
KT_VERSION="1.0.0"
ROOT="${KT_ROOT:-}"          # yalnızca deneme için: dosyalar bu klasörün altına yazılır
MODE=install
for a in "$@"; do case "$a" in --remove) MODE=remove ;; --no-activate) MODE=noact ;; esac; done

TPL=/usr/share/ucode/luci/template/themes
[ -d "$ROOT$TPL" ] || [ -n "$ROOT" ] || { echo "Bu LuCI sürümü desteklenmiyor (ucode şablon klasörü yok: $TPL). OpenWrt 23.05 ve üstü gerekir."; exit 1; }
[ -d "$ROOT/www/luci-static" ] || [ -n "$ROOT" ] || { echo "/www/luci-static bulunamadı; LuCI kurulu görünmüyor."; exit 1; }

clear_cache() { rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache 2>/dev/null; }

if [ "$MODE" = remove ]; then
	if [ -z "$ROOT" ] && command -v uci >/dev/null 2>&1; then
		cur=$(uci -q get luci.main.mediaurlbase)
		if [ "$cur" = /luci-static/kedi ]; then
			prev=$(cat /etc/luci-theme-kedi.prev 2>/dev/null)
			[ -n "$prev" ] || prev=/luci-static/bootstrap
			uci set luci.main.mediaurlbase="$prev"
		fi
		uci -q delete luci.themes.Kedi
		uci commit luci
	fi
	rm -rf "$ROOT/www/luci-static/kedi" "$ROOT/www/luci-static/resources/menu-kedi.js" "$ROOT/www/luci-static/resources/view/kedi" "$ROOT$TPL/kedi" "$ROOT/etc/luci-theme-kedi.prev"
	[ -z "$ROOT" ] && clear_cache
	echo "luci-theme-kedi kaldırıldı."
	exit 0
fi

put() { # put <hedef> <kip> ; içerik stdin'den
	mkdir -p "$(dirname "$1")" && cat > "$1" && chmod "$2" "$1"
}
put "$ROOT/www/luci-static/kedi/cascade.css" 644 <<'KT_EOF_1'
/*!
 * LuCI Bootstrap Theme
 * Copyright 2012 Nut & Bolt
 * By David Menting <david@nut-bolt.nl>
 * Based on Bootstrap v1.4.0
 *
 * Copyright 2011 Twitter, Inc
 * Licensed under the Apache License v2.0
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Designed and built with all the love in the world @twitter by @mdo and @fat.
 */

/* Variables
 * --------- */

:root {
	--background-color-delta-l-sign: -1;
	--background-color-h: 0;
	--background-color-s: 0%;
	--background-color-l: 100%;

	--background-color-high-hsl:
		var(--background-color-h),
		var(--background-color-s),
		var(--background-color-l);
	--background-color-high: hsl(var(--background-color-high-hsl));

	--background-color-medium-hsl:
		var(--background-color-h),
		var(--background-color-s),
		calc(var(--background-color-l) + var(--background-color-delta-l-sign) * 2.35%);
	--background-color-medium: hsl(var(--background-color-medium-hsl));

	--background-color-low-hsl:
		var(--background-color-h),
		var(--background-color-s),
		calc(var(--background-color-l) + var(--background-color-delta-l-sign) * 3.92%);
	--background-color-low: hsl(var(--background-color-low-hsl));

	--text-color-delta-l-sign: 1;
	--text-color-h: 0;
	--text-color-s: 0%;
	--text-color-l: 0%;

	--text-color-highest-hsl:
		var(--text-color-h),
		var(--text-color-s),
		var(--text-color-l);
	--text-color-highest: hsl(var(--text-color-highest-hsl));

	--text-color-high-hsl:
		var(--text-color-h),
		var(--text-color-s),
		calc(var(--text-color-l) + var(--text-color-delta-l-sign) * 25.1%);
	--text-color-high: hsl(var(--text-color-high-hsl));

	--text-color-medium-hsl:
		var(--text-color-h),
		var(--text-color-s),
		calc(var(--text-color-l) + var(--text-color-delta-l-sign) * 50.2%);
	--text-color-medium: hsl(var(--text-color-medium-hsl));

	--text-color-low-hsl:
		var(--text-color-h),
		var(--text-color-s),
		calc(var(--text-color-l) + var(--text-color-delta-l-sign) * 74.9%);
	--text-color-low: hsl(var(--text-color-low-hsl));

	--border-color-delta-l-sign: -1;
	--border-color-h: var(--background-color-h);
	--border-color-s: var(--background-color-s);
	--border-color-l: var(--background-color-l);

	--border-color-high-hsl:
		var(--border-color-h),
		var(--border-color-s),
		calc(var(--border-color-l) + var(--border-color-delta-l-sign) * 20%);
	--border-color-high: hsl(var(--border-color-high-hsl));

	--border-color-medium-hsl:
		var(--border-color-h),
		var(--border-color-s),
		calc(var(--border-color-l) + var(--border-color-delta-l-sign) * 13.33%);
	--border-color-medium: hsl(var(--border-color-medium-hsl));

	--border-color-low-hsl:
		var(--border-color-h),
		var(--border-color-s),
		calc(var(--border-color-l) + var(--border-color-delta-l-sign) * 6.67%);
	--border-color-low: hsl(var(--border-color-low-hsl));

	--primary-color-high: #1976d2;
	--primary-color-medium: #1564c0;
	--primary-color-low: #0d46a1;
	--on-primary-color: var(--background-color-high);

	--error-color-high-rgb: 246, 43, 18;
	--error-color-high: rgb(var(--error-color-high-rgb));
	--error-color-medium: #e8210d;
	--error-color-low: #d00000;
	--on-error-color: var(--background-color-high);

	--success-color-high-rgb: 0, 172, 89;
	--success-color-high: rgb(var(--success-color-high-rgb));
	--success-color-medium: #009a4c;
	--success-color-low: #007936;
	--on-success-color: var(--background-color-high);

	--warn-color-high: #efbd0b;
	--warn-color-medium: #f0c629;
	--warn-color-low: #f2d24f;
	--on-warn-color: var(--text-color-highest);

	--disabled-opacity: .7;

	color-scheme: light;

	--font-sans: Helvetica Neue, Helvetica, Arial, ui-sans-serif, system-ui, sans-serif;
	--font-mono: Monaco, Andale Mono, Courier New, ui-monospace, monospace;
}

:root[data-darkmode="true"] {
	--background-color-delta-l-sign: 1;
	--background-color-h: 0;
	--background-color-s: 0%;
	--background-color-l: 13.33%;
	--text-color-delta-l-sign: -1;
	--text-color-h: 0;
	--text-color-s: 0%;
	--text-color-l: 100%;
	--border-color-delta-l-sign: 1;

	--primary-color-high: #4da1c0;
	--primary-color-medium: #448da6;
	--primary-color-low: #3c7a8d;

	--error-color-high-rgb: 209, 86, 83;
	--error-color-medium: #bf4e4c;
	--error-color-low: #b14946;

	--success-color-high-rgb: 0, 166, 108;
	--success-color-medium: #00945e;
	--success-color-low: #008252;

	--warn-color-high: #a69461;
	--warn-color-medium: #a68d45;
	--warn-color-low: #a68732;
	--on-warn-color: var(--background-color-high);

	--disabled-opacity: .4;

	color-scheme: dark;
}

/* Reset.less
 * Props to Eric Meyer (meyerweb.com) for his CSS reset file. We're using an adapted version here	that cuts out some of the reset HTML elements we will never need here (i.e., dfn, samp, etc).
 * ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */

* {
	scroll-margin-top: 40px;
}

*, *::before, *::after {
	margin: 0;
	padding: 0;
	border: 0;
	box-sizing: border-box;
}

abbr[title], acronym[title] {
	border-bottom: 1px dotted;
	font-weight: inherit;
	cursor: help;
}

table {
	border-collapse: collapse;
	border-spacing: 0;
}

ol, ul {
	list-style: none;
}

html {
	font-size: 100%;
	height: 100%;
}

a:focus {
	outline: thin dotted;
}

a:hover, a:active {
	outline: 0;
}

sub, sup {
	font-size: 75%;
	line-height: 0;
	position: relative;
	vertical-align: baseline;
}

sup {
	top: -0.5em;
}

sub {
	bottom: -0.25em;
}

img {
	-ms-interpolation-mode: bicubic;
}

button,
input,
select,
option,
textarea {
	font-size: 100%;
	margin: 0;
	box-sizing: border-box;
	vertical-align: baseline;
	line-height: 2em;
}

button,
input[type="button"],
input[type="reset"],
input[type="submit"] {
	cursor: pointer;
	-webkit-appearance: button; /* nonstandard, should remove in future */
	appearance: button;
	word-break: break-all;
}

button[disabled],
input[type="button"][disabled],
input[type="reset"][disabled],
input[type="submit"][disabled] {
	opacity: var(--disabled-opacity);
}

input[type="search"] {
	-webkit-appearance: textfield; /* nonstandard, should remove in future */
	appearance: textfield;
	box-sizing: content-box;
}

input[type="search"]::-webkit-search-decoration {
	-webkit-appearance: none; /* nonstandard, should remove in future */
	appearance: none;
}

textarea {
	overflow: auto;
	vertical-align: top;
	font-family: monospace;
}

.control-group {
	display: inline-flex;
	gap: .2em;
}

.control-group > input + :not(input):not(select),
.control-group > select + :not(input):not(select) {
	margin-left: calc(-.2em + -2px);
	border-radius: 0 3px 3px 0;
	padding: 0 6px;
}

/*
 * Scaffolding
 * Basic and global styles for generating a grid system, structural layout, and page templates
 * ------------------------------------------------------------------------------------------- */
body {
	background-color: var(--background-color-high);
	font-family: var(--font-sans);
	font-size: 13px;
	font-weight: normal;
	line-height: 18px;
	color: var(--text-color-high);
	padding: 5px;
	min-height: 100%;
	display: flex;
	flex-direction: column;
	overflow-y: scroll;
}

.container {
	width: 100%;
	max-width: 1180px;
	margin-left: auto;
	margin-right: auto;
	zoom: 1;
}

a {
	color: var(--primary-color-high);
	text-decoration: none;
	line-height: inherit;
	font-weight: inherit;
}

a:hover {
	color: var(--primary-color-low);
	text-decoration: underline;
}

.pull-right {
	float: right;
}

.pull-left {
	float: left;
}

.nowrap:not(span) {
/*	Sometimes you need to wrap: badges on narrow screens look weird 
	and nowrap defeats other width constraints, so exclude span */
	white-space: nowrap;
}

/* Typography.less
 * Headings, body text, lists, code, and more for a versatile and durable typography system
 * ---------------------------------------------------------------------------------------- */
p,
.cbi-map-descr,
.cbi-section-descr,
.table .tr.cbi-section-table-descr .th {
	font-size: 13px;
	font-weight: normal;
	line-height: 18px;
	margin-bottom: 9px;
}

p small {
	font-size: 11px;
	color: var(--text-color-low);
}

h1,
h2,
h3, legend,
h4,
h5,
h6 {
	font-weight: bold;
	color: var(--text-color-high);
}

h1 small,
h2 small,
h3 small,
h4 small,
h5 small,
h6 small {
	color: var(--text-color-low);
}

h1 {
	margin-bottom: 18px;
	font-size: 30px;
	line-height: 36px;
}

h1 small {
	font-size: 18px;
}

h2 {
	font-size: 24px;
	line-height: 36px;
}

h2 small {
	font-size: 14px;
}

h3, legend,
h4,
h5,
h6 {
	line-height: 36px;
}

h3, legend {
	font-size: 18px;
}

h3 small {
	font-size: 14px;
}

h4 {
	font-size: 16px;
}

h4 small {
	font-size: 12px;
}

h5 {
	font-size: 14px;
}

h6 {
	font-size: 13px;
	color: var(--text-color-low);
	text-transform: uppercase;
}

ul, ol {
	margin: 0 0 18px 25px;
}

ul ul,
ul ol,
ol ol,
ol ul {
	margin-bottom: 0;
}

ul {
	list-style: disc;
}

ol {
	list-style: decimal;
}

li {
	line-height: 18px;
	color: var(--text-color-medium);
}

ul.unstyled {
	list-style: none;
	margin-left: 0;
}

dl {
	margin-bottom: 18px;
}

dl dt, dl dd {
	line-height: 18px;
}

dl dt {
	font-weight: bold;
}

dl dd {
	margin-left: 9px;
}

hr {
	margin: 20px 0 19px;
	border: 0;
	border-bottom: 1px solid var(--border-color-low);
}

strong {
	font-style: inherit;
	font-weight: bold;
}

em {
	font-style: italic;
	font-weight: inherit;
	line-height: inherit;
}

small { font-size: 0.9em }

address {
	display: block;
	line-height: 18px;
	margin-bottom: 18px;
}

code, pre {
	padding: 0 3px 2px;
	font-family: var(--font-mono);
	font-size: 12px;
	border-radius: 3px;
}

code {
	background-color: var(--border-color-low);
	color: var(--text-color-high);
	padding: 1px 3px;
}

pre {
	--border-color-h: var(--background-color-h);
	--border-color-s: var(--background-color-s);
	--border-color-delta-l: 100%;
	--border-color-l: calc(var(--background-color-l) + var(--background-color-delta-l-sign) * var(--border-color-delta-l));
	--border-color-a: 0.15;
	--border-color: hsla(var(--border-color-hsl), var(--border-color-a));

	background-color: var(--background-color-low);
	display: block;
	padding: 8.5px;
	margin: 0 0 18px;
	line-height: 18px;
	font-size: 12px;
	border: 1px solid var(--border-color);
	border-radius: 3px;
	white-space: pre;
	white-space: pre-wrap;
	word-wrap: break-word;
}

/* Forms.less
 * Base styles for various input types, form layouts, and states
 * ------------------------------------------------------------- */
fieldset {
	margin-bottom: 9px;
	padding-top: 9px;
}

fieldset legend {
	display: block;
	font-size: 19.5px;
	line-height: 1;
	color: var(--text-color-high);
	padding-top: 20px;
}

label,
input,
button,
select {
	font-family: var(--font-sans);
	font-size: 13px;
	font-weight: normal;
	line-height: normal;
}

.cbi-value {
	display: flex;
	flex-wrap: wrap;
	margin-bottom: 18px;
	align-items: baseline;
}

.cbi-value-field {
	margin-left: 20px;
	flex: 1;
}

.cbi-value label.cbi-value-title {
	padding-top: 6px;
	font-size: 13px;
	line-height: 18px;
	flex: 0 0 180px;
	text-align: right;
	color: var(--text-color-high);
}

.cbi-value > .cbi-section,
.cbi-value > .cbi-tblsection {
	width: 100%;
}

label > input[type="checkbox"],
label > input[type="radio"] {
	vertical-align: text-top;
	margin: 0;
}

label[for] {
	cursor: pointer;
}

input,
textarea,
select,
.cbi-select,
.cbi-dropdown:not(.btn):not(.cbi-button) {
	display: inline-block;
	width: 210px;
	padding: 4px;
	background: var(--background-color-high);
	color: var(--text-color-high);
	font-size: 13px;
	line-height: 18px;
	border: 1px solid var(--border-color-high);
	border-radius: 3px;
}

@media screen and (min-width: 768px) {
	#localtime {
		width: 300px;
	}
}

input,
select,
.cbi-select,
.cbi-dropdown:not(.btn):not(.cbi-button) {
	height: 30px;
}

.cbi-dropdown:not(.btn):not(.cbi-button),
.cbi-dynlist {
	min-width: 210px;
	max-width: 400px;
	width: auto;
}

.cbi-dynlist {
	height: auto;
	min-height: 30px;
	display: inline-flex;
	flex-direction: column;
}

.cbi-dynlist > .item {
	margin-bottom: 4px;
	box-shadow: 0 0 2px var(--border-color-high);
	background: var(--background-color-high);
	padding: 6px 2em 6px 4px;
	border: 1px solid var(--border-color-high);
	border-radius: 3px;
	color: var(--text-color-high);
	position: relative;
	pointer-events: auto; /* needed for drag-and-drop in UIDynamicList */
	overflow: hidden;
	word-break: break-all;
	cursor: move; /* drag-and-drop */
	user-select: text; /* text selection in drag-and-drop */
}

.cbi-dynlist > .item::after {
	content: "×";
	position: absolute;
	display: inline-flex;
	align-items: center;
	top: -1px;
	right: -1px;
	bottom: -1px;
	padding: 0 6px;
	border: 1px solid var(--border-color-high);
	border-radius: 0 3px 3px 0;
	font-weight: bold;
	color: #c44;
	pointer-events: auto;
}

/* indication line for drag-and-drop in UIDynamicList*/
.cbi-dynlist > .item.drag-over { 
	border-top: 1px solid var(--text-color-highest);
}

/* Make item being dragged in UIDynamicList partially transparent*/
.cbi-dynlist > .item.dragging {
	opacity: 0.5;
}

/* prevent pointer changing when over the span element in UIDynamicList */
.cbi-dynlist > .item > span {
	pointer-events: none;
}

.cbi-dynlist > .add-item {
	display: flex;
}

/* indication line for drag-and-drop in UIDynamicList*/
.cbi-dynlist > .add-item > .cbi-input-text.drag-over {
	border-top: 1px solid var(--text-color-highest);
}

/* indication line for drag-and-drop in UIDynamicList*/
.cbi-dynlist > .add-item > .cbi-button-add.drag-over {
	border-top: 1px solid var(--text-color-highest);
}

.cbi-dynlist > .add-item > input,
.cbi-dynlist > .add-item > button {
	flex: 1 1 auto;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.cbi-value-field > .cbi-checkbox,
.cbi-value-field > div > .cbi-radio {
	height: 30px;
	display: inline-flex;
	align-items: center;
}

.cbi-radio {
	cursor: pointer;
	gap: .125em;
}

.cbi-select {
	padding: 0;
	position: relative;
	background: linear-gradient(var(--background-color-high), var(--border-color-low));
}

.cbi-select select,
.cbi-select select:focus {
	-webkit-appearance: none; /* nonstandard, should remove in future */
	appearance: none;
	outline: none;
	border: none;
	background: transparent;
	height: 100%;
	width: 100%;
	padding: 0 .3em;
	cursor: pointer;
	margin-right: .6em;
}

.cbi-select::before {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	content: "▾";
	padding: 0 .3em;
	background: linear-gradient(var(--background-color-high), var(--border-color-low));
	pointer-events: none;
	border-radius: 3px;
	display: flex;
	flex-direction: column;
	justify-content: center;
}

.cbi-select select option {
	background: var(--background-color-low);
	color: var(--text-color-high);
}

.cbi-select select option:hover {
	background: var(--primary-color-low);
	color: var(--on-primary-color);
}

.cbi-select select option:checked {
	background: var(--primary-color-medium);
	color: var(--on-primary-color);
}

input[type=file] {
	padding: initial;
	border: initial;
	line-height: initial;
	box-shadow: none;
	width: auto !important;
}

input[type=button], input[type=reset], input[type=submit] {
	width: auto;
	height: auto;
}

select[multiple] {
	height: inherit;
	background-color: #fff;
}

input[type="checkbox"],
input[type="radio"] {
	--bd-color: var(--border-color-high);
	--fg-color: var(--text-color-high);
	-webkit-appearance: none; /* nonstandard, should remove in future */
	appearance: none;
	width: 14px;
	height: 14px;
	color: var(--fg-color);
	position: relative;
	display: inline-block;
	cursor: pointer;
	background: none;
	border: none;
}

input[type="checkbox"]::before,
input[type="checkbox"]::after,
input[type="radio"]::before,
input[type="radio"]::after {
	position: absolute;
	content: "";
}

input[type="checkbox"]::before,
input[type="radio"]::before {
	top: 0;
	left: 0;
	width: 14px;
	height: 14px;
	background: linear-gradient(var(--background-color-high), var(--background-color-low));
	border: 1px solid var(--bd-color);
	border-radius: 2px;
}

input[type="radio"],
input[type="radio"]::before {
	border-radius: 50%;
}

input[type="checkbox"]::after,
input[type="radio"]::after {
	top: 2px;
	left: 2px;
	width: 10px;
	height: 10px;
}

input[type="checkbox"]:checked::after,
input[type="radio"]:checked::after {
	--checkmark-icon: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20'><path d='m2.5 7.4 7.5 7.5-2.5 2.4L0 10Zm15-5L20 4.9 7.5 17.3 5 15Z'/></svg>");
	-webkit-mask: var(--checkmark-icon) center/cover no-repeat;
	mask: var(--checkmark-icon) center/cover no-repeat;
	background: var(--fg-color);
}

input[type="radio"]:checked:after {
	--checkmark-icon: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20'><circle cx='10' cy='10' r='7'/></svg>");
}

input[type="checkbox"].cbi-input-invalid,
input[type="radio"].cbi-input-invalid {
	--bd-color: var(--error-color-medium);
	--fg-color: var(--error-color-high);
}

.td > input[type=text],
.td > input[type=password],
.td > select,
.td > .cbi-dropdown:not(.btn):not(.cbi-button),
.cbi-dynlist > .add-item > .cbi-dropdown {
	width: 100%;
}

::placeholder {
	color: var(--text-color-medium);
}

.item::after,
.btn,
.cbi-button,
.cbi-select,
.cbi-dropdown,
.cbi-dynlist > .item,
input[type="checkbox"]::before,
input[type="radio"]::before,
input, button, textarea, select {
	transition: border linear 0.2s, box-shadow linear 0.2s;
	box-shadow: inset 0 1px 3px hsla(var(--border-color-low-hsl), .01);
}

.item:hover::after,
.btn:hover, .btn:focus,
.cbi-button:hover, .cbi-button:focus,
.cbi-select.focus,
.cbi-dropdown:focus, .cbi-dropdown[open],
.cbi-dynlist > .item:focus,
input[type="checkbox"]:focus::before,
input[type="radio"]:focus::before,
input:focus, button:hover, textarea:focus, select:focus {
	--focus-color-rgb: 82, 168, 236;

	outline: 0;
	border-color: rgba(var(--focus-color-rgb), 0.8) !important;
	box-shadow: inset 0 1px 3px hsla(var(--border-color-low-hsl), .01), 0 0 8px rgba(var(--focus-color-rgb), 0.6);
	text-decoration: none;
}

.cbi-input-invalid:focus,
.cbi-select.cbi-input-invalid,
input[type="checkbox"].cbi-input-invalid:focus::before,
input[type="radio"].cbi-input-invalid:focus::before {
	--focus-color-rgb: var(--error-color-high-rgb);
}

input[disabled],
button[disabled],
select[disabled],
textarea[disabled],
.cbi-select[disabled]::before,
.cbi-dropdown[disabled]:not(.btn):not(.cbi-button),
input[type="checkbox"][disabled]::before,
input[type="checkbox"][disabled]::after,
input[type="radio"][disabled]::before,
input[type="radio"][disabled]::after {
	opacity: var(--disabled-opacity);
	pointer-events: none;
	cursor: default;
}

input[readonly],
select[readonly],
textarea[readonly] {
	border-color: hsla(var(--border-color-high-hsl), var(--disabled-opacity));
	pointer-events: auto;
	cursor: auto;
}

.cbi-optionals,
.cbi-section-create {
	padding: 0 0 10px 10px;
}

.cbi-section-create {
	margin: -3px;
	display: inline-flex;
	align-items: center;
}

.cbi-section-create > * {
	margin: 3px;
	flex: 1 1 auto;
}

.cbi-section-create > * > input {
	width: 100%;
}

.actions,
.cbi-page-actions {
	background: var(--background-color-low);
	margin-bottom: 18px;
	padding: 17px 20px 18px 17px;
	border-top: 1px solid var(--border-color-medium);
	border-radius: 0 0 3px 3px;
	text-align: right;
}

.actions .secondary-action,
.cbi-page-actions .secondary-action{
	float: right;
}

.actions .secondary-action a,
.cbi-page-actions .secondary-action a {
	line-height: 30px;
}

.actions .secondary-action a:hover,
.cbi-page-actions .secondary-action a:hover {
	text-decoration: underline;
}

.cbi-page-actions > form {
	display: inline;
	margin: 0;
}

/*
 * Tables.less
 * Tables for, you guessed it, tabular data
 * ---------------------------------------- */
.tr { display: table-row; }
.table[width="33%"], .th[width="33%"], .td[width="33%"] { width: 33%; }
.table[width="100%"], .th[width="100%"], .td[width="100%"] { width: 100%; }

.table {
	display: table;
	width: 100%;
	margin-bottom: 18px;
	padding: 0;
	font-size: 13px;
	border-collapse: collapse;
	position: relative;
}

.table .th, .table .td {
	display: table-cell;
	vertical-align: middle; /* Fixme */
	padding: 10px 10px 9px;
	line-height: 18px;
	text-align: left;
}

.table .tr:first-child .th {
	padding-top: 9px;
	font-weight: bold;
	vertical-align: top;
}

.table .td, .table .th {
	border-top: 1px solid var(--border-color-medium);
}

.tr.placeholder {
	height: calc(3em + 20px);
}

.tr.placeholder > .td {
	position: absolute;
	left: 0;
	right: 0;
	bottom: 0;
	text-align: center;
	line-height: 3em;
}

.tr.drag-over-above,
.tr.drag-over-below {
	border: 2px solid #0069d6;
	border-width: 2px 0 0 0;
}

.tr.drag-over-below {
	border-width: 0 0 2px 0;
}

/* Patterns.less
 * Repeatable UI elements outside the base styles provided from the scaffolding
 * ---------------------------------------------------------------------------- */
header {
	position: sticky;
	top: 0;
	z-index: 800;
	overflow: visible;
	color: #BFBFBF;
	margin: -5px -5px 15px -5px;
	display: flex;
}

header a {
	color: #bfbfbf;
	text-shadow: 0 -1px 0 hsla(var(--border-color-low-hsl), .25);
}

header .brand:hover, header ul .active > a {
	background-color: #333;
	background-color: rgba(255, 255, 255, 0.05);
	color: #fff;
	text-decoration: none;
}

header .brand {
	float: left;
	display: block;
	padding: 8px 20px 12px;
	margin-left: -15px;
	color: #fff;
	font-size: 20px;
	font-weight: 200;
	line-height: 1;
}

header .pull-right {
	margin-left: auto;
	margin-right: 5px;
	align-self: center;
}

header p {
	margin: 0;
	line-height: 40px;
}

header {
	background: linear-gradient(#333333, #222222);
	box-shadow: 0 1px 3px hsla(var(--border-color-low-hsl), .25), inset 0 -1px 0 hsla(var(--border-color-low-hsl), .01);
	padding: 0;
	/* the redundant properties below work around a csstidy bug */
	padding-left: calc((100% - 1180px) / 2);
	padding-right: calc((100% - 1180px) / 2);
}

.nav {
	display: block;
	float: left;
	margin: 0 10px 0 0;
	position: relative;
	left: 0;
}

.nav > li {
	display: block;
	float: left;
}

.nav a {
	display: block;
	float: none;
	padding: 10px 10px 11px;
	line-height: 19px;
	text-decoration: none;
}

.nav a:hover {
	color: #fff;
	text-decoration: none;
}

.nav .active > a {
	background-color: #222;
	background-color: rgba(0, 0, 0, 0.5);
}

.nav a.menu:hover {
	background: #444;
	background: rgba(255, 255, 255, 0.05);
}

.nav .dropdown-menu {
	background-color: #333;
}

.nav .dropdown-menu a.menu {
	color: #fff;
}

.nav .dropdown-menu li a {
	color: #999;
	text-shadow: 0 1px 0 rgba(0, 0, 0, 0.5);
}

.nav .dropdown-menu li a:hover {
	background-color: #191919;
	background-repeat: repeat-x;
	background-image: linear-gradient(to bottom, #292929, #191919);
	color: #fff;
}

.nav .dropdown-menu .active a {
	color: #fff;
}

.nav .dropdown-menu li a {
	padding: 4px 15px;
}

li.menu, .dropdown {
	position: relative;
}

a.menu:after {
	width: 0;
	height: 0;
	display: inline-block;
	content: "&darr;";
	text-indent: -99999px;
	vertical-align: top;
	margin-top: 8px;
	margin-left: 4px;
	border-left: 4px solid transparent;
	border-right: 4px solid transparent;
	border-top: 4px solid #fff;
	opacity: 0.5;
}

.dropdown-menu {
	background-color: #fff;
	float: left;
	position: absolute;
	top: 40px;
	left: -9999px;
	z-index: 900;
	min-width: max-content;
	margin-left: 0;
	margin-right: 0;
	padding: 6px 0;
	zoom: 1;
	border-color: #999;
	border-color: rgba(0, 0, 0, 0.2);
	border-style: solid;
	border-width: 0 1px 1px;
	border-radius: 0 0 6px 6px;
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
	background-clip: padding-box;
}

.dropdown-menu li {
	float: none;
	display: block;
	background-color: transparent;
}

.dropdown-menu a {
	display: block;
	padding: 4px 15px;
	clear: both;
	font-weight: normal;
	line-height: 18px;
	color: #808080;
	text-shadow: 0 1px 0 #fff;
}

.dropdown-menu a:hover {
	background-color: #ddd;
	background-repeat: repeat-x;
	background-image: linear-gradient(to bottom, #eee, #ddd);
	color: #404040;
	text-decoration: none;
	box-shadow: inset 0 1px 0 rgba(0, 0, 0, 0.025), inset 0 -1px rgba(0, 0, 0, 0.025);
}

.dropdown:hover ul.dropdown-menu {
	left: 0;
}

.dropdown-menu .dropdown-menu {
	position: absolute;
	left: 159px;
}

.dropdown-menu li {
	position: relative;
}

.tabs, .cbi-tabmenu {
	--tab-bar-background-color: var(--background-color-high);
	--tab-inactive-background-color-h: var(--border-color-low-h);
	--tab-inactive-background-color-s: var(--border-color-low-s);
	--tab-inactive-background-color-l: var(--border-color-low-l);
	--tab-inactive-background-color: var(--border-color-low);
	--tab-inactive-border-color: var(--border-color-medium);
	--tab-inactive-text-color-delta-l: 33.33%;
	--tab-inactive-text-color-l: calc(var(--tab-inactive-background-color-l) + var(--background-color-delta-l-sign) * var(--tab-inactive-text-color-delta-l));
	--tab-inactive-text-color: hsl(var(--tab-inactive-background-color-hsl));
	--tab-inactive-hover-background-color: var(--background-color-high);
	--tab-active-background-color: var(--background-color-high);
	--tab-active-text-color: #0069d6;
	--tab-active-border-color: var(--border-color-medium);

	margin: 0 -5px 18px;
	padding: 0 2px;
	list-style: none;
	display: flex;
	flex-wrap: wrap;
	background: linear-gradient(var(--tab-bar-background-color) 28px, var(--tab-inactive-border-color) 28px);
	background-size: 1px 29px;
	background-position: left bottom;
}

.tabs > li, .cbi-tabmenu > li {
	flex: 0 1 auto;
	display: flex;
	align-items: center;
	height: 25px;
	max-width: 48%;
	margin: 4px 2px 0 2px;
	background: var(--tab-active-background-color);
	border: 1px solid var(--tab-active-border-color);
	border-bottom: none;
	border-radius: 4px 4px 0 0;
	color: var(--primary-color-high);
}

.tabs > li > a, .cbi-tabmenu > li > a {
	padding: 4px 6px;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	color: inherit;
	text-decoration: none;
	border-radius: 4px 4px 0 0;
	line-height: 25px;
	outline: none;
}

.tabs > li > a:focus-visible, .cbi-tabmenu > li > a:focus-visible {
	text-decoration: underline;
}

.tabs > li:not(.active):hover, .cbi-tabmenu > .cbi-tab-disabled:hover {
	background: linear-gradient(var(--tab-inactive-hover-background-color) 90%, var(--tab-inactive-border-color) 100%);
}

.tabs > li:not(.active), .cbi-tabmenu > .cbi-tab-disabled {
	color: var(--tab-inactive-text-color);
	background: linear-gradient(var(--tab-inactive-background-color) 90%, var(--tab-inactive-border-color) 100%);
}

.cbi-tab-disabled[data-errors]::after {
	content: attr(data-errors);
	background: #c43c35;
	color: #fff;
	height: 16px;
	min-width: 16px;
	border-radius: 8px;
	text-align: center;
	margin: 0 5px 0 0;
	padding: 3px 2px 1px 2px;
	display: inline-flex;
	flex-direction: column;
	justify-content: center;
	font-size: 12px;
}

.cbi-tabmenu.map {
	margin: 0;
}

.cbi-tabmenu.map > li {
	font-size: 16.5px;
	font-weight: bold;
}

.cbi-tab-descr {
	margin: -9px 0 18px 0;
}

.tabs .menu-dropdown, .tabs .dropdown-menu {
	top: 35px;
	border-width: 1px;
	border-radius: 0 6px 6px 6px;
}

.tabs a.menu:after, .tabs .dropdown-toggle:after {
	border-top-color: #999;
	margin-top: 15px;
	margin-left: 5px;
}

.tabs li.open.menu .menu, .tabs .open.dropdown .dropdown-toggle {
	border-color: #999;
}

.tabs li.open a.menu:after, .tabs .dropdown.open .dropdown-toggle:after {
	border-top-color: #555;
}

.tab-content > .tab-pane,
.tab-content > div {
	display: none;
}

.tab-content > .active {
	display: block;
}

.breadcrumb {
	padding: 7px 14px;
	margin: 0 0 18px;
	background: linear-gradient(to bottom, var(--background-color-high), var(--background-color-low));
	border: 1px solid var(--border-color-medium);
	border-radius: 3px;
	display: flex;
	flex: 0;
}

.breadcrumb li {
	list-style: none;
}

.breadcrumb li:not(:last-child)::after {
	content: "|";
	padding: 0 5px;
}

.breadcrumb .active a {
	color: var(--text-color-medium);
}

footer {
	padding-top: 17px;
	margin-top: auto;
	border-top: 1px solid var(--border-color-low);
	display: flex;
	flex-wrap: wrap;
	align-items: baseline;
	justify-content: space-between;
	font-size: 12px;
	color: var(--text-color-medium);
	/* the redundant properties below work around a csstidy bug */
	/* Match footer with header padding left and right so they are aligned (header uses 1180px, but footer was using 940px) */ 
	padding-left: calc((100% - 1180px) / 2);
	padding-right: calc((100% - 1180px) / 2);
}

footer a {
	color: var(--primary-color-low);
}

footer span {
	margin-bottom: 1em;
}

footer ul.breadcrumb {
	margin-left: auto;
}

#modal_overlay {
	position: fixed;
	top: 0;
	bottom: 0;
	background: rgba(0, 0, 0, 0.7);
	z-index: 900;
	overflow: auto;
	transition: opacity .125s ease-in;
	opacity: 0;
	visibility: hidden;
}

.modal {
	width: 90%;
	margin: 5em auto;
	min-height: 32px;
	max-width: 600px;
	border-radius: 3px;
	background: var(--background-color-high);
	border: 1px solid var(--border-color-low);
	box-shadow: 0 0 3px var(--background-color-low);
	padding: 1em 1em .5em 1em;
	min-width: 270px;
}

.modal > * {
	line-height: normal;
	margin-bottom: .5em;
	max-width: 100%;
}

.modal > pre,
.modal > textarea {
	white-space: pre-wrap;
	overflow: auto;
	width: 100%;
}

.modal > .button-row {
	display: flex;
	justify-content: space-between;
	flex-wrap: wrap;
}

.modal > .button-row > button:not(:last-of-type) {
	margin-right: .5em;
}

.modal > .button-row > button:first-of-type {
	margin-right: auto;
}

body.modal-overlay-active {
	overflow: hidden;
	height: 100vh;
}

body.modal-overlay-active #modal_overlay {
	left: 0;
	right: 0;
	opacity: 1;
	visibility: visible;
}

.btn .close, .alert-message .close {
	font-family: var(--font-sans);
	line-height: 18px;
}

.btn.danger,
.alert-message.danger,
.btn.error,
.alert-message.error,
.cbi-tooltip.error {
	background: linear-gradient(var(--error-color-low), var(--error-color-medium));
	color: var(--on-error-color);
	border-color: var(--error-color-high) var(--error-color-high) var(--error-color-low);
}

.btn.success, .alert-message.success, .cbi-tooltip.success {
	background: linear-gradient(var(--success-color-low), var(--success-color-medium));
	color: var(--on-error-color);
	border-color: var(--success-color-high) var(--success-color-high) var(--success-color-low);
}

.btn.info, .alert-message.info, .cbi-tooltip.info {
	background: linear-gradient(var(--primary-color-low), var(--primary-color-medium));
	color: var(--on-primary-color);
	border-color: var(--primary-color-high) var(--primary-color-high) var(--primary-color-low);
}

.alert-message.notice, .cbi-tooltip.notice {
	background: linear-gradient(var(--background-color-low), var(--background-color-medium));
	border-color: var(--background-color-high) var(--background-color-high) var(--background-color-low);
	color: var(--text-color-high);
}

.alert-message.warning {
	background: linear-gradient(var(--warn-color-low), var(--warn-color-medium));
	border-color: var(--warn-color-high) var(--warn-color-high) var(--warn-color-low);
	color: var(--on-warn-color);
}

.modal.alert-message {
	color: var(--text-color-high);
}

.item::after,
.btn,
.cbi-button {
	--default-btn-background: linear-gradient(var(--background-color-high), var(--background-color-high) 25%, var(--background-color-low));
	--on-color: var(--text-color-high);

	cursor: pointer;
	display: inline-block;
	background: var(--default-btn-background);
	padding: 0 14px;
	color: var(--on-color);
	font-size: 13px;
	line-height: 2em;
	border: 1px solid var(--border-color-high);
	border-radius: 4px;
	white-space: pre;
}

.cbi-input-invalid,
.cbi-input-invalid.cbi-dropdown:not(.btn):not(.cbi-button),
.cbi-input-invalid.cbi-dropdown:not([open]) > ul > li,
.cbi-value-error input {
	color: var(--error-color-high);
	border-color: var(--error-color-medium);
}

.cbi-button-positive,
.cbi-button-fieldadd,
.cbi-button-add,
.cbi-button-save {
	--on-color: var(--success-color-high);
	border-color: var(--on-color);
}

.cbi-button-neutral,
.cbi-button-download,
.cbi-button-find,
.cbi-button-link,
.cbi-button-up,
.cbi-button-down {
	color: var(--text-color-high);
}

.btn.primary,
.cbi-button-action,
.cbi-button-apply,
.cbi-button-reload,
.cbi-button-edit {
	--on-color: var(--primary-color-high);
	border-color: var(--on-color);
}

.cbi-button-negative,
.cbi-section-remove .cbi-button,
.cbi-button-reset,
.cbi-button-remove {
	--on-color: var(--error-color-high);
	border-color: var(--on-color);
}

.cbi-page-actions::after {
	display: table;
	content: "";
	clear: both;
}

.cbi-page-actions > * {
	vertical-align: middle;
}

.cbi-page-actions > :not([method="post"]):not(.cbi-button-apply):not(.cbi-button-negative):not(.cbi-button-save):not(.cbi-button-reset) {
	float: left;
	margin-right: .4em;
}

.btn.primary,
.cbi-button-action.important,
.cbi-page-actions .cbi-button-apply,
.cbi-section-actions .cbi-button-edit {
	--on-color: var(--on-primary-color);
	background: linear-gradient(var(--primary-color-medium), var(--primary-color-low));
	border-color: var(--primary-color-high);
}

.cbi-button-positive.important,
.cbi-page-actions .cbi-button-save {
	--on-color: var(--on-success-color);
	background: linear-gradient(var(--success-color-medium), var(--success-color-low));
	border-color: var(--success-color-high);
}

.cbi-button-negative.important {
	--on-color: var(--on-error-color);
	background: linear-gradient(var(--error-color-medium), var(--error-color-low));
	border-color: var(--error-color-high);
}

.cbi-page-actions .cbi-button-apply + .cbi-button-save,
.cbi-page-actions .cbi-button-negative + .cbi-button-save {
	--on-color: var(--success-color-high);
	border-color: var(--on-color);
	background: var(--default-btn-background);
}

.cbi-dropdown {
	display: inline-flex !important;
	cursor: pointer;
	height: auto;
	position: relative;
	padding: 0 !important;
}

.cbi-dropdown:not(.btn):not(.cbi-button) {
	background: linear-gradient(var(--background-color-high) 0%, var(--border-color-low) 100%);
	border: 1px solid var(--border-color-high);
	border-radius: 3px;
	color: var(--text-color-high);
}

.cbi-dropdown img {
	/* the following are necessary to constrain (vector) images of any size */
	max-height: 1.6em;  /* Adjusts image height to fit slightly larger than text line height */
	width: auto;  /* Preserves aspect ratio */
}

.cbi-dropdown > ul {
	margin: 0 !important;
	padding: 0;
	list-style: none;
	overflow-x: hidden;
	overflow-y: hidden;
	display: flex;
	width: 100%;
}

.cbi-dropdown.btn > ul:not(.dropdown),
.cbi-dropdown.cbi-button > ul:not(.dropdown) {
	margin: 0 0 0 13px !important;
}

.cbi-dropdown.btn.spinning > ul:not(.dropdown),
.cbi-dropdown.cbi-button.spinning > ul:not(.dropdown) {
	margin: 0 !important;
}

.cbi-dropdown > ul.preview {
	display: none;
}

.cbi-dropdown > .open,
.cbi-dropdown > .more {
	flex-grow: 0;
	flex-shrink: 0;
	display: flex;
	flex-direction: column;
	justify-content: center;
	text-align: center;
	line-height: 2em;
	padding: 0 .3em;
}

.cbi-dropdown.btn > .open,
.cbi-dropdown.cbi-button > .open {
	padding: 0 .5em;
	margin-left: .5em;
	border-left: 1px solid;
}

.cbi-dropdown > .more,
.cbi-dropdown:not(.btn):not(.cbi-button) > ul > li[placeholder] {
	color: var(--text-color-medium);
	display: none;
}

.cbi-dropdown > ul > li {
	display: none;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	flex-shrink: 1;
	flex-grow: 1;
	align-items: center;
	align-self: center;
	color: inherit;
}

.cbi-dropdown > ul.dropdown > li,
.cbi-dropdown:not(.btn):not(.cbi-button) > ul > li {
	min-height: 20px;
	padding: .25em;
	color: var(--text-color-high);
}

.cbi-dropdown > ul > li .hide-open { display: block; display: initial; }
.cbi-dropdown > ul > li .hide-close { display: none; }

.cbi-dropdown > ul > li[display]:not([display="0"]) {
	border-left: 1px solid var(--border-color-high);
}

.cbi-dropdown[empty] > ul {
	max-width: 1px;
}

.cbi-dropdown > ul > li > form {
	display: none;
	margin: 0;
	padding: 0;
	pointer-events: none;
}

.cbi-dropdown > ul > li img {
	vertical-align: middle;
	margin-right: .25em;
}

.cbi-dropdown > ul > li > form > input[type="checkbox"] {
	margin: 0 .25em 0 0;
}

.cbi-dropdown > ul > li input[type="text"] {
	height: 20px;
}

.cbi-dropdown[open] {
	position: relative;
}

.cbi-dropdown[open] > ul.dropdown {
	display: block;
	background: var(--background-color-low);
	border: 1px solid #918e8c;
	box-shadow: 0 0 4px #918e8c;
	position: absolute;
	z-index: 1100;
	max-width: none;
	min-width: 100%;
	width: auto;
	transition: max-height .125s ease-in;
	overflow-y: auto;
}

.cbi-dropdown > ul > li[display],
.cbi-dropdown[open] > ul.preview,
.cbi-dropdown[open] > ul.dropdown > li,
.cbi-dropdown[multiple] > ul > li > label,
.cbi-dropdown[multiple][open] > ul.dropdown > li,
.cbi-dropdown[multiple][more] > .more,
.cbi-dropdown[multiple][empty] > .more {
	flex-grow: 1;
	display: flex !important;
}

.cbi-dropdown[empty] > ul > li,
.cbi-dropdown[optional][open] > ul.dropdown > li[placeholder] {
	display: block !important;
}

.cbi-dropdown[multiple][open] > ul.dropdown > li > form {
	display: flex !important;
}

.cbi-dropdown[open] > ul.dropdown > li .hide-open { display: none; }
.cbi-dropdown[open] > ul.dropdown > li .hide-close { display: block; display: initial; }

.cbi-dropdown[open] > ul.dropdown > li {
	border-bottom: 1px solid var(--border-color-high);
}

.cbi-dropdown[open] > ul.dropdown > li[selected] {
	background: var(--primary-color-medium);
	color: var(--on-primary-color);
}

.cbi-dropdown[open] > ul.dropdown > li.focus,
.cbi-dropdown[open] > ul.dropdown > li:hover {
	background: var(--primary-color-low);
	color: var(--on-primary-color);
}

.cbi-dropdown[open] > ul.dropdown > li[selected].focus,
.cbi-dropdown[open] > ul.dropdown > li[selected]:hover {
	background: linear-gradient(90deg, var(--primary-color-medium) 50%, var(--primary-color-low));
}

.cbi-dropdown[open] > ul.dropdown > li:last-child {
	margin-bottom: 0;
	border-bottom: none;
}

.cbi-dropdown[open] > ul.dropdown > li[unselectable] {
	opacity: 0.7;
}

.cbi-dropdown[open] > ul.dropdown > li > input.create-item-input:first-child:last-child {
	width: 100%;
}

.cbi-title-ref {
	color: #37c;
}

.cbi-title-ref::after {
	content: "➙";
}

.cbi-tooltip-container {
	cursor: help;
}

.cbi-tooltip {
	position: absolute;
	z-index: 1000;
	left: -10000px;
	box-shadow: 0 0 2px var(--border-color-high);
	border-radius: 3px;
	background: var(--background-color-high);
	white-space: pre;
	padding: 2px 5px;
	opacity: 0;
	transition: opacity .25s ease-in;
}

.cbi-tooltip-container:hover .cbi-tooltip:not(:empty) {
	left: auto;
	opacity: 1;
	transition: opacity .25s ease-in;
}

.cbi-progressbar {
	border: 1px solid var(--border-color-high);
	border-radius: 3px;
	position: relative;
	min-width: 170px;
	height: 8px;
	margin: 1.4em 0 4px 0;
	background: var(--background-color-medium);
}

.cbi-progressbar > div {
	background: var(--primary-color-medium);
	height: 100%;
	transition: width .25s ease-in;
	width: 0%;
	border-radius: 2px;
}

.cbi-progressbar::before {
	position: absolute;
	top: -1.4em;
	left: 0;
	content: attr(title);
	white-space: pre;
	overflow: hidden;
	text-overflow: ellipsis;
}

.zonebadge .cbi-tooltip {
	padding: 1px;
	background: inherit;
	margin: -1.6em 0 0 -5px;
	border-radius: 3px;
	pointer-events: none;
	box-shadow: 0 0 3px #444;
}

.zonebadge .cbi-tooltip > * {
	margin: 1px;
	z-index: 2;
	position: relative;
}

.zone-forwards {
	display: flex;
	flex-wrap: nowrap;
}

.zone-forwards > * {
	flex: 1 1 40%;
	padding: 1px;
	text-wrap: auto;
}

.zone-forwards > span {
	flex-basis: 10%;
	text-align: center;
}

.zone-forwards .zone-src,
.zone-forwards .zone-dest {
	display: flex;
	flex-direction: column;
}

.btn.active, .btn:active {
	box-shadow: inset 0 2px 4px hsla(var(--border-color-low-hsl), .25), 0 1px 2px rgba(0, 0, 0, 0.05);
}

.btn.disabled,
.btn[disabled] {
	cursor: default;
	opacity: var(--disabled-opacity);
	box-shadow: none;
}

.btn.large {
	font-size: 15px;
	line-height: normal;
	padding: 9px 14px 9px;
	border-radius: 6px;
}

.btn.small {
	padding: 7px 9px 7px;
	font-size: 11px;
}

.close {
	float: right;
	color: #000;
	font-size: 20px;
	font-weight: bold;
	line-height: 13.5px;
	text-shadow: 0 1px 0 #fff;
	opacity: 0.25;
}

.close:hover {
	color: #000;
	text-decoration: none;
	opacity: 0.4;
}

.alert-message {
	position: relative;
	padding: .5em .5em .25em .5em;
	margin-bottom: .5em;
	color: var(--on-warn-color);
	background: linear-gradient(#fceec1, #eedc94);
	border: 1px solid var(--border-color-low);
	border-color: var(--border-color-high) var(--border-color-high) var(--border-color-low);
	border-radius: 4px;
	box-shadow: 1px 1px 1px var(--border-color-low);
	white-space: unset;
}

.alert-message .close {
	margin-top: 1px;
}

.alert-message h4,
.alert-message h5,
.alert-message pre,
.alert-message ul,
.alert-message li,
.alert-message p {
	color: inherit;
	border: none;
	line-height: inherit;
	background: transparent;
	padding: 0;
	margin: .25em 0;
}

.alert-message button {
	margin: .25em 0;
}

.label,
header [data-indicator] {
	padding: 3px 3px 2px;
	font-size: 9.75px;
	font-weight: bold;
	color: var(--text-color-high);
	text-transform: uppercase;
	white-space: nowrap;
	background-color: var(--background-color-low);
	border-radius: 3px;
	text-shadow: none;
	margin: .125em 0 .125em .4em;
}

header [data-indicator][data-clickable] {
	cursor: pointer;
}

a.label:link,
a.label:visited {
	color: #fff;
}

a.label:hover {
	text-decoration: none;
}

.label.important {
	background-color: var(--primary-color-high);
	color: var(--on-primary-color);
}

.label.warning {
	background-color: var(--warn-color-high);
	color: var(--on-warn-color);
}

.label.success {
	background-color: var(--success-color-high);
	color: var(--on-success-color);
}

.label.notice,
header [data-indicator][data-style="active"] {
	color: var(--on-primary-color);
	background-color: var(--primary-color-high);
}

/* LuCI specific items */
.hidden { display: none }

form.inline { display: inline; margin-bottom: 0; }

#modemenu li:last-child span.divider { display: none }

#syslog {
	width: 100%;
	color: var(--text-color-highest);
	margin-bottom: 18px;
	font-family: monospace;
}

.cbi-section-table .tr:hover .td,
.cbi-section-table .tr:hover .th,
.cbi-section-table .tr:hover::before {
	background-color: var(--background-color-low);
}

.cbi-section-table .tr.cbi-section-table-descr .th {
	font-weight: normal;
}

.cbi-section-table-titles {
	font-weight: bold;
}

.cbi-section-table-descr.named::before,
.cbi-section-table-row[data-title]::before {
	content: none;
}

.cbi-section-table-titles.named::before,
.cbi-section-table-descr.named::before,
.cbi-section-table-row[data-title]::before {
	border-top: 1px solid var(--border-color-medium);
}

.left { text-align: left !important; }
.right { text-align: right !important; }
.center { text-align: center !important; }
.top { vertical-align: top !important; }
.middle { vertical-align: middle !important; }
.bottom { vertical-align: bottom !important; }

table table td,
.cbi-value-field table td {
	border: none;
}

.table.cbi-section-table input[type="password"],
.table.cbi-section-table input[type="text"],
.table.cbi-section-table textarea,
.table.cbi-section-table select,
.table.cbi-section-table .cbi-select {
	width: 100%;
	min-width: auto;
}

.table.cbi-section-table .td.cbi-section-table-cell {
	white-space: nowrap;
	text-align: right;
}

.table.cbi-section-table .td.cbi-section-table-cell select,
.table.cbi-section-table .td.cbi-section-table-cell .cbi-select {
	width: inherit;
}

.td.cbi-section-actions {
	text-align: right;
	vertical-align: middle;
	width: 15%;
}

.td.cbi-section-actions > * {
	display: flex;
}

.td.cbi-section-actions > :not(.cbi-dropdown) > *,
.td.cbi-section-actions > * > form > * {
	flex: 1 1 4em;
	margin: 0 1px;
}

.td.cbi-section-actions > * > form {
	display: inline-flex;
	margin: 0;
}

.table.valign-middle .td {
	vertical-align: middle;
}

.cbi-rowstyle-2,
.tr.table-titles,
.tr.cbi-section-table-titles {
	background: var(--background-color-medium);
}

th[data-sortable-row] { cursor: pointer; }
th[data-sort-direction="asc"]::after { content: "\a0\25b2"; }
th[data-sort-direction="desc"]::after { content: "\a0\25bc"; }

.cbi-value-description {
	margin: .25em 0 0 1.25em;
	position: relative;
}

.cbi-value-description:not(:empty)::before {
	--help-icon: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20'><path d='M10 0A10 10 0 000 10a10 10 0 0010 10 10 10 0 0010-10A10 10 0 0010 0zm1 17H9v-2h2v2zm2.1-7.7l-.9.9c-.8.7-1.2 1.3-1.2 2.8H9v-.5c0-1.1.4-2.1 1.2-2.8l1.2-1.3c.4-.3.6-.8.6-1.4a2 2 0 00-2-2 2 2 0 00-2 2H6a4 4 0 014-4 4 4 0 014 4c0 .9-.4 1.7-.9 2.3z'/></svg>");

	position: absolute;
	left: -1.25em;
	content: "\a0";
	display: inline-block;
	width: 1em;
	height: 1em;
	margin-right: .25em;
	background: var(--primary-color-high);
	mask-image: var(--help-icon);
	mask-size: cover;
	-webkit-mask-image: var(--help-icon);
	-webkit-mask-size: cover;
}

.cbi-section-error {
	border: 1px solid #f00;
	border-radius: 3px;
	background-color: #fce6e6;
	padding: 5px;
	margin-bottom: 18px;
}

.cbi-section-error ul { margin: 0 0 0 20px; }

.cbi-section-error ul li {
	color: #f00;
	font-weight: bold;
}

.ifacebox {
	border: 1px solid var(--border-color-high);
	margin: 0 10px;
	text-align: center;
	white-space: nowrap;
	background: linear-gradient(var(--background-color-high), var(--background-color-medium));
	border-radius: 4px;
	box-shadow: inset 0 1px 0 hsla(var(--text-color-low-hsl), 0.05);
	display: inline-flex;
	flex-direction: column;
	line-height: 1.2em;
	min-width: 100px;
}

.ifacebox .ifacebox-head {
	border-bottom: 1px solid var(--border-color-high);
	border-radius: 3px 3px 0 0;
	padding: 2px;
	background: #eee;
	color: var(--text-color-high);
}

.ifacebox .ifacebox-head[style] {
	text-shadow: 0 1px 1px hsla(var(--background-color-high-hsl), 0.75);
}

.ifacebox .ifacebox-head.active {
	background: var(--primary-color-high);
	color: var(--on-primary-color);
}

[data-darkmode="true"] .zonebadge[style],
[data-darkmode="true"] .ifacebox-head[style] {
	background: linear-gradient(rgba(var(--zone-color-rgb), .4), rgba(var(--zone-color-rgb), .3)) !important;
}

.ifacebox .ifacebox-body {
	padding: .25em;
}

#cbi-network-interface .ifacebox-body {
	white-space: normal;
}

#cbi-network-interface .ifacebox img {
	width: 24px;
	height: 24px;
}

.ifacebadge {
	display: inline-block;
	flex-direction: row;
	border: 1px solid var(--border-color-high);
	padding: 2px;
	background: linear-gradient(var(--background-color-high), var(--background-color-high) 25%, var(--background-color-medium));
	color: var(--text-color-high);
	text-shadow: 0 1px 1px hsla(var(--background-color-high-hsl), 0.75);
	border-radius: 4px;
	box-shadow: inset 0 1px 0 hsla(var(--background-color-high-hsl), 0.05);
	cursor: default;
	line-height: 1.2em;
}

.ifacebadge img {
	width: 32px;
	height: 32px;
	vertical-align: middle;
}

.ifacebadge-active {
	border-color: #000;
	font-weight: bold;
}

.network-status-table {
	display: flex;
	flex-wrap: wrap;
}

.network-status-table .ifacebox {
	margin: .5em;
	flex-grow: 1;
}

.network-status-table .ifacebox-body {
	display: flex;
	flex-direction: column;
	height: 100%;
	text-align: left;
}

.network-status-table .ifacebox-body > * {
	margin: .25em;
}

.network-status-table .ifacebox-body > span {
	flex: 10 10 auto;
	height: 100%;
}

.network-status-table .ifacebox-body > div {
	margin: -.125em;
	display: flex;
	flex-wrap: wrap;
}

#dsl_status_table .ifacebox-body span > strong {
	display: inline-block;
	min-width: 35%;
}

.ifacebadge.large,
.network-status-table .ifacebox-body .ifacebadge {
	display: flex;
	flex: 1;
	padding: .25em;
	min-width: 220px;
	margin: .125em;
}

.ifacebadge.large {
	display: inline-flex;
}

.network-status-table .ifacebox-body .ifacebadge > span {
	overflow: hidden;
	text-overflow: ellipsis;
}

.ifacebadge > *,
.ifacebadge.large > * {
	margin: 0 .125em;
}

.zonebadge {
	padding: 2px;
	border-radius: 4px;
	display: inline-block;
	white-space: nowrap;
	color: var(--text-color-high);
	text-shadow: 0 1px 1px hsla(var(--background-color-high-hsl), 0.75);
}

.zonebadge > em,
.zonebadge > strong {
	margin: 0 2px;
	display: inline-block;
}

.zonebadge input {
	width: 6em;
}

.zonebadge > .ifacebadge {
	margin-left: 2px;
}

.zonebadge-empty {
	border: 1px dashed #aaa;
	color: #aaa;
	font-style: italic;
	font-size: smaller;
}

div.cbi-value var,
.td.cbi-value-field var {
	font-style: italic;
	color: #0069d6;
}

div.cbi-value var[data-tooltip],
.td.cbi-value-field var[data-tooltip],
div.cbi-value var.cbi-tooltip-container,
.td.cbi-value-field var.cbi-tooltip-container {
	cursor: help;
	border-bottom: 1px dotted #0069d6;
}

div.cbi-value var.cbi-tooltip-container,
.td.cbi-value-field var.cbi-tooltip-container .cbi-tooltip {
	font-style: normal;
	white-space: normal;
	color: var(--text-color-high);
}

#modal_overlay > .modal.uci-dialog,
#modal_overlay > .modal.cbi-modal {
	max-width: 900px;
}

#modal_overlay > .modal.login > button.important {
	font-size: 120% !important;
	margin-top: .5em;
	width: 100%;
}

.uci-change-list {
	line-height: 170%;
	white-space: pre;
}

.uci-dialog div > del,
.uci-dialog div > ins,
.uci-dialog div > var {
	margin-bottom: 2px;
	border: 1px solid var(--border-color-high);
	line-height: 15px;
	overflow: hidden;
	text-overflow: ellipsis;
	padding: 2px;
	position: relative;
	background-color: var(--background-color-low);
}

.uci-dialog div > ins {
	background-color: rgba(var(--success-color-high-rgb), .3);
	border-color: rgba(var(--success-color-high-rgb), .6);
}

.uci-dialog div > del {
	background-color: rgba(var(--error-color-high-rgb), .3);
	border-color: rgba(var(--error-color-high-rgb), .6);
}

.uci-dialog var > ins {
	background-color: rgba(var(--success-color-high-rgb), .3);
}

.uci-dialog var > del {
	background-color: rgba(var(--error-color-high-rgb), .3);
}

.uci-change-list > var > * {
	overflow: hidden;
	text-overflow: ellipsis;
}

.uci-dialog del,
.uci-dialog ins,
.uci-dialog var {
	text-decoration: none;
	font-family: monospace;
	font-style: normal;
	color: var(--text-color-high);
	display: block;
}

.uci-change-legend {
	display: flex;
	flex-wrap: wrap;
}

.uci-change-legend-label {
	flex-basis: 150px;
	margin: 2px;
	display: flex;
	align-items: center;
}

.uci-change-legend-label > ins,
.uci-change-legend-label > del,
.uci-change-legend-label > var {
	margin-right: 4px;
	width: 16px;
	height: 16px;
	display: flex;
}

.uci-change-legend-label > * > * {
	flex-basis: 100%;
	padding: 1px;
}

#applyreboot-section {
	line-height: 300%;
}

@keyframes flash {
	0% { opacity: 1; }
	50% { opacity: .5; }
	100% { opacity: 1; }
}

.flash {
	animation: flash .35s;
}

#view > div.spinning:first-child {
	display: table;
	margin: 15vh auto;
}

.spinning {
	position: relative;
	padding-left: 32px !important;
}

.spinning::before {
	--spinner-icon: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' stroke='%23000' stroke-width='3' fill='none'><circle cx='10' cy='10' r='8' stroke-opacity='.5'/><path d='M10 2c4 0 8 4 8 8'><animateTransform attributeName='transform' type='rotate' dur='1s' from='0 10 10' to='360 10 10' repeatCount='indefinite'/></path></svg>");

	position: absolute;
	top: calc(50% - 10px);
	left: 6px;
	width: 20px;
	height: 20px;
	content: " ";
	background: var(--on-color, #000);
	mask: var(--spinner-icon) center/cover no-repeat;
	-webkit-mask: var(--spinner-icon) center/cover no-repeat;
}

[data-darkmode="true"] .spinning::before {
	background: var(--on-color, #fff);
}

[data-tab-title] {
	height: 0;
	opacity: 0;
	overflow: hidden;
}

[data-tab-active="true"] {
	opacity: 1;
	height: auto;
	overflow: visible;
	transition: opacity .25s ease-in;
}

.cbi-filebrowser {
	min-width: 210px;
	max-width: 100%;
	border: 1px solid #ccc;
	border-radius: 3px;
	display: flex;
	flex-direction: column;
	opacity: 0;
	height: 0;
	overflow: hidden;
}

.cbi-filebrowser.open {
	opacity: 1;
	height: auto;
	overflow: visible;
	transition: opacity .25s ease-in;
}

.cbi-filebrowser > * {
	max-width: 100%;
	overflow: hidden;
	text-overflow: ellipsis;
	padding: 0 0 .25em 0;
	margin: .25em .25em 0px .25em;
	white-space: nowrap;
	border-bottom: 1px solid #ccc;
}

.cbi-filebrowser .cbi-button-positive {
	margin-right: .25em;
}

.cbi-filebrowser > div {
	border-bottom: none;
}

.cbi-filebrowser > ul > li {
	display: flex;
	flex-direction: row;
}

.cbi-filebrowser > ul > li:hover {
	background: #f5f5f5;
}

.cbi-filebrowser > ul > li > div:first-child {
	flex: 10;
	overflow: hidden;
	text-overflow: ellipsis;
}

.cbi-filebrowser > ul > li > div:last-child {
	flex: 3;
	text-align: right;
}

.cbi-filebrowser > ul > li > div:last-child > button {
	padding: .125em .25em;
	margin: 1px 0 1px .25em;
}

.cbi-filebrowser .upload {
	display: flex;
	flex-direction: row;
	flex-wrap: wrap;
	margin: 0 -.125em .25em -.125em;
	padding: 0 0 .125em 0px;
	border-bottom: 1px solid #ccc;
}

.cbi-filebrowser .upload > * {
	margin: .125em;
	flex: 1;
}

.cbi-filebrowser .upload > .btn {
	flex-basis: 60px;
}

.cbi-filebrowser .upload > div {
	flex: 10;
	min-width: 150px;
}

.cbi-filebrowser .upload > div > input {
	width: 100%;
}

@keyframes fade-in {
	0% { opacity: 0; }
	100% { opacity: 1; }
}

@keyframes fade-out {
	0% { opacity: 1; }
	100% { opacity: 0; }
}

.fade-in {
	animation: fade-in .4s ease;
}

.fade-out {
	animation: fade-out .4s ease;
}

.assoclist .ifacebadge {
	display: flex;
	flex-direction: column;
	align-items: center;
	white-space: normal;
	text-align: center;
}

.assoclist .ifacebadge > img {
	margin: .2em;
}

.assoclist .td:nth-of-type(3),
.assoclist .td:nth-of-type(5) {
	width: 25%;
}

.assoclist .td:nth-of-type(6) button {
	word-break: normal;
}

[data-darkmode="true"] [data-page="admin-statistics-graphs"] [data-plugin] img {
	filter: invert(100%) hue-rotate(150deg);
}

[data-page="admin-system-admin-sshkeys"] .cbi-dynlist {
	max-width: none;
}

#view div[style] > svg {
	background-color: var(--background-color-high)!important;
}

#view div[style] > svg line[style] {
	stroke: var(--text-color-highest)!important;
}

/* === STATUS OVERVIEW: HIDE/SHOW BUTTONS === */

/* Change mouse icon from text cursor to pointer */
body[data-page='admin-status-overview'] .cbi-title .label {
  cursor: pointer;
}

/* Smaller buttons on larger screens */
@media screen and (min-width : 481px) {
  body[data-page='admin-status-overview'] .cbi-title .label {
    line-height: 1em;
    margin: 0.7em 0;
  }
}

/* Slightly fade "show" button */
body[data-page='admin-status-overview'] .cbi-title .label.notice {
  opacity: var(--disabled-opacity);
}

/* Remove fade when hovered */
body[data-page='admin-status-overview'] .cbi-title .label.notice:hover {
  opacity: initial;
}

/* === END STATUS OVERVIEW: HIDE/SHOW BUTTONS === */
KT_EOF_1
put "$ROOT/www/luci-static/kedi/mobile.css" 644 <<'KT_EOF_2'
header h3 a, header .brand {
	display:none !important;
}

@media screen and (max-device-width: 600px) {
	.modal {
		margin: 1.5em auto;
	}

	.tabs, .cbi-tabmenu {
		background: linear-gradient(var(--background-color-high) 20%, var(--border-color-medium) 100%);
		background-size: 1px 34px;
		margin-bottom: 10px;
	}

	.tabs > li, .cbi-tabmenu > li {
		height: 30px;
	}

	.tabs > li > a, .cbi-tabmenu > li > a {
		padding: 0 8px;
		line-height: 30px;
	}

	.table {
		display: flex;
		flex-direction: column;
		width: 100%;
	}

	.tr {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		align-items: flex-end;
		border-top: 1px solid var(--border-color-medium);
		padding: 5px 0;
		margin: 0 -3px;
	}

	.table .th,
	.table .td,
	.table .tr::before {
		flex: 1 1 50%;
		align-self: flex-start;
		overflow: hidden;
		text-overflow: ellipsis;
		word-wrap: break-word;
		display: inline-block;
		border-top: none;
		padding: 3px;
		box-sizing: border-box;
	}

	.table .td.cbi-dropdown-open {
		overflow: visible;
	}

	.col-1 { flex: 1 1 30px !important; -webkit-flex: 1 1 30px !important; }
	.col-2 { flex: 2 2 60px !important; -webkit-flex: 2 2 60px !important; }
	.col-3 { flex: 3 3 90px !important; -webkit-flex: 3 3 90px !important; }
	.col-4 { flex: 4 4 120px !important; -webkit-flex: 4 4 120px !important; }
	.col-5 { flex: 5 5 150px !important; -webkit-flex: 5 5 150px !important; }
	.col-6 { flex: 6 6 180px !important; -webkit-flex: 6 6 180px !important; }
	.col-7 { flex: 7 7 210px !important; -webkit-flex: 7 7 210px !important; }
	.col-8 { flex: 8 8 240px !important; -webkit-flex: 8 8 240px !important; }
	.col-9 { flex: 9 9 270px !important; -webkit-flex: 9 9 270px !important; }
	.col-10 { flex: 10 10 300px !important; -webkit-flex: 10 10 300px !important; }

	.td select {
		word-wrap: normal;
	}

	.td[data-widget="button"],
	.td[data-widget="fvalue"] {
		flex: 1 1 17%;
		text-align: left;
	}

	.td.cbi-value-field {
		align-self: flex-start;
		flex-basis: 100%;
		margin-bottom: .3em;
	}

	.td.cbi-value-field .cbi-button {
		width: 100%;
	}

	.table.cbi-section-table {
		border: none;
		background: none;
		margin: 0;
	}

	.tr.table-titles,
	.cbi-section-table-titles,
	.cbi-section-table-descr {
		display: none;
	}

	.cbi-section-table-row {
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		margin: 0 0 .5em 0;
	}

	.cbi-section-table + .cbi-section-create {
		padding-top: 0;
	}

	.tr[data-title]::before {
		display: block;
		flex: 1 1 100%;
		background: var(--background-color-low) !important;
		font-size: 16px;
		border-bottom: 1px solid var(--border-color-medium);
	}

	.td[data-title]::before {
		content: attr(data-title);
		font-weight: bold;
		display: block;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: pre-line;
	}

	.td[data-description]::after {
		display: block;
	}

	.td[data-title] ~ .td.cbi-section-actions {
		align-self: flex-start;
	}

	.td.cbi-section-actions {
		overflow: initial;
		max-width: 100%;
		padding: 3px 2px;
		flex-basis: 100%;
	}

	.hide-sm,
	.hide-xs {
		display: none !important;
	}

	.td.cbi-value-field[data-widget="CBI.DummyValue"],
	.td.cbi-value-field[data-widget="CBI.Button"],
	.td.cbi-value-field[data-widget="CBI.FlagValue"],
	.td.cbi-value-field[data-widget="dvalue"],
	.td.cbi-value-field[data-widget="button"],
	.td.cbi-value-field[data-widget="fvalue"] {
		flex-basis: 50%;
		text-align: left;
	}

	.cbi-section-table .tr:hover .td,
	.cbi-section-table .tr:hover .th,
	.cbi-section-table .tr:hover::before {
		background-color: transparent;
	}

	.cbi-tab-descr {
		margin: 0 0 .5em 0;
	}

	.cbi-value {
		padding-bottom: .5em;
		border-bottom: 1px solid var(--border-color-high);
		margin-bottom: .5em;
		display: block;
		align-items: baseline;
	}

	.cbi-value.hidden {
		display: none;
	}

	.cbi-value .cbi-value:last-child {
		border-bottom: none;
		padding-bottom: inherit;
		margin-bottom: inherit;
	}

	.cbi-value label.cbi-value-title {
		font-weight: bold;
	}

	.cbi-value-field, .cbi-select, .cbi-dynlist, .cbi-dropdown:not(.btn):not(.cbi-button) {
		width: 100%;
		margin: 0;
	}

	.cbi-dynlist > .item {
		min-height: 30px;
		display: flex;
		align-items: center;
	}

	input, textarea, select,
	.cbi-dropdown > ul > li {
		font-size: 16px !important;
		height: auto;
	}

	.cbi-dropdown > ul > li input[type="text"] {
		line-height: 28px;
	}

	select, input[type="text"], input[type="password"],
	.cbi-dropdown > ul > li input[type="text"],
	.cbi-value-field .control-group {
		width: 100%;
		height: 30px;
	}

	input.cbi-input-password {
		width: calc(100% - 25px);
	}

	input[type="text"] + .cbi-button,
	input[type="password"] + .cbi-button,
	select + .cbi-button {
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.cbi-value-field input[type="checkbox"],
	.cbi-value-field input[type="radio"] {
		margin: 0;
	}

	button, .btn, .cbi-button {
		font-size: 14px !important;
		padding: 0 8px;
	}

	.actions,
	.cbi-page-actions {
		border-top: none;
		margin-top: -.5em;
		padding: 8px;
	}

	[data-page="admin-status-overview"] .td[width="33%"] {
		flex-basis: 33%;
	}

	header .pull-right .label {
		white-space: normal;
		display: inline-block;
		text-align: center;
		line-height: 12px;
		margin: 1px 0;
	}

	header > .fill {
		padding: 1px;
	}

	header > .fill > .container {
		display: flex;
		flex-direction: row;
	}

	header .nav {
		flex: 3 3 80%;
		margin: 2px 5px 2px 0;
		display: flex;
		flex-wrap: wrap;
		justify-content: flex-start;
	}

	header .nav a {
		padding: 2px 6px;
	}

	header .pull-right {
		display: flex;
		flex-direction: column;
		padding: 0;
		justify-content: space-around;
		margin: .2em 5px .2em auto;
	}

	.menu-dropdown, .dropdown-menu {
		top: 23px;
	}

	.cbi-optionals,
	.cbi-section-create {
		padding: 0 0 14px 0;
	}

	#cbi-network-switch_vlan .th,
	#cbi-network-switch_vlan .td {
		flex-basis: 12%;
	}

	#cbi-network-switch_vlan .td.cbi-section-actions > * {
		width: auto;
		display: block;
	}

	#wifi_assoclist_table .td,
	[data-page="admin-status-processes"] .td {
		flex-basis: 50% !important;
	}

	[data-page="admin-status-processes"] .td[data-widget="button"] {
		flex-basis: 33% !important;
	}

	[data-page="admin-status-processes"] .td[data-name="PID"],
	[data-page="admin-status-processes"] .td[data-name="USER"] {
		flex-basis: 25% !important;
	}

	[data-page="admin-system-fstab"] .td[data-widget="button"]::before,
	[data-page="admin-system-startup"] .td[data-widget="button"]::before,
	[data-page="admin-status-processes"] .td[data-widget="button"]::before {
		display: none;
	}

	[data-name="bridge-vlan"] > div {
		overflow: visible !important;
	}

	[data-name="bridge-vlan"] .td[data-title] {
		flex-basis: 33%;
	}

	[data-name="bridge-vlan"] .td[data-title]::before {
		content: attr(data-title);
	}

	[data-page="admin-network-network"] .td[data-name="_ifacebox"] {
		flex-basis: 40%;
	}

	[data-page="admin-network-network"] .td[data-name="_ifacestat"] {
		flex-basis: 60%;
	}
}

@media screen and (max-device-width: 375px) {
	.cbi-page-actions {
		display: flex;
		justify-content: space-between;
		margin: 0 -1px;
		padding: 0;
	}

	.cbi-page-actions button {
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.cbi-page-actions .cbi-button {
		flex: 1;
		margin: 1px !important;
		line-height: 2em;
	}

	.cbi-page-actions .cbi-button-negative,
	.cbi-page-actions .cbi-button-primary,
	.cbi-page-actions .cbi-button-apply {
		flex: 3;
	}

	.cbi-section-actions .cbi-button {
		overflow: hidden;
		text-overflow: ellipsis;
		margin: 1px !important;
	}

	body[data-page="admin-network-wireless"] .td[data-name="_badge"] {
		max-width: 50px;
		align-self: center;
	}

	body[data-page="admin-network-wireless"] .td[data-name="_badge"] .ifacebadge {
		display: flex;
		align-items: center;
		flex-direction: column;
	}

	body[data-page="admin-network-wireless"] .td[data-name="_stat"] {
		flex-basis: 60%;
	}

	body[data-page="admin-network-network"] .td.cbi-section-actions::before,
	body[data-page="admin-network-wireless"] .td.cbi-section-actions::before {
		content: none !important;
	}

	[data-page="admin-network-network"] .td[data-name="_ifacebox"],
	[data-page="admin-network-network"] .td[data-name="_ifacestat"] {
		flex-basis: 100%;
	}

	.td .ifacebox {
		width: 100%;
		margin: 0 !important;
		flex-direction: row;
	}

	.td .ifacebox .ifacebox-head {
		min-width: 25%;
		justify-content: space-around;
		border-radius: 4px 0 0 4px;
	}

	.td .ifacebox .ifacebox-head,
	.td .ifacebox .ifacebox-body {
		display: flex;
		border-bottom: none;
		align-items: center;
	}

	.td .ifacebox .ifacebox-head > *,
	.ifacebox .ifacebox-body > * {
		margin: .125em;
	}
}
KT_EOF_2
put "$ROOT/www/luci-static/kedi/kedi.css" 644 <<'KT_EOF_3'
/* luci-theme-kedi — Bootstrap'in renk değişkenlerini Kedi paletiyle değiştirir; ardından ortak Kedi kuralları gelir. */
:root[data-kedi]{
	--background-color-h:262;--background-color-s:40%;--background-color-l:9%;
	--primary-color-high:#8B5CF6;--primary-color-medium:#7C3AED;--primary-color-low:#6D28D9;--on-primary-color:#fff;
	--error-color-high-rgb:242,112,109;--error-color-high:#F2706D;--error-color-medium:#E25B58;--error-color-low:#D4504D;--on-error-color:#fff;
	--success-color-high-rgb:61,209,111;--success-color-high:#3DD16F;--success-color-medium:#2FBF60;--success-color-low:#25A652;--on-success-color:#0b1a10;
	--warn-color-high:#F0B429;--warn-color-medium:#E3A81E;--warn-color-low:#D49A12;--on-warn-color:#1b1200;
	--font-sans:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
}
:root[data-kedi="light"]{
	--background-color-h:255;--background-color-s:100%;--background-color-l:98%;
	--text-color-h:262;--text-color-s:45%;--text-color-l:12%;
}
:root[data-kedi="dark"]{
	--background-color-delta-l-sign:1;--text-color-delta-l-sign:-1;--border-color-delta-l-sign:1;
	--text-color-h:262;--text-color-s:30%;--text-color-l:95%;
}
/* KediRay · Kedi tasarım sistemi (mor) — tüm KediRay sayfaları bu dosyayı kullanır.
   Yalnızca görünümdür: veri, düğme davranışı ve CLI çıktıları değişmez.
   Etkinleştirme: krTheme() <html data-kedi="dark|light"> yazar (Otomatik = sistem teması).
   Renk modeli, AW1K Panel (Android) ThemeDef ile aynıdır: bg, accent, panel, panelEnd, good, warn, bad. */

/* KediRay · Kedi tasarım sistemi (mor) — tüm KediRay sayfaları bu dosyayı kullanır.
   Yalnızca görünümdür: veri, düğme davranışı ve CLI çıktıları değişmez.
   Etkinleştirme: krTheme() <html data-kedi="dark|light"> yazar (Otomatik = sistem teması).
   Renk modeli, AW1K Panel (Android) ThemeDef ile aynıdır: bg, accent, panel, panelEnd, good, warn, bad. */

html[data-kedi]{
	--k-bg:#110B1E;--k-bg2:#160F27;--k-card:#1B1330;--k-card2:#251A41;--k-in:#1F1636;
	--k-line:rgba(196,181,253,.15);--k-line2:rgba(196,181,253,.28);
	--k-ink:#EEE9FB;--k-soft:#B8AED3;--k-mute:#8B80AA;
	--k-accent:#C4B5FD;--k-a1:#4C1D95;--k-a2:#7C3AED;--k-on:#fff;
	--k-good:#3DD16F;--k-warn:#F0B429;--k-bad:#F2706D;--k-bolt:#FBBF24;--k-direct:#5EEAD4;
	--k-shadow:0 1px 0 rgba(255,255,255,.04) inset,0 10px 30px -14px rgba(0,0,0,.65);
	--k-r1:22px;--k-r2:14px;--k-r3:10px;
	color-scheme:dark;
}
html[data-kedi="light"]{
	--k-bg:#F5F2FF;--k-bg2:#EFEBFB;--k-card:#FFFFFF;--k-card2:#F3EEFF;--k-in:#FFFFFF;
	--k-line:rgba(76,29,149,.14);--k-line2:rgba(76,29,149,.3);
	--k-ink:#1E1233;--k-soft:#54487A;--k-mute:#7B709B;
	--k-accent:#6D28D9;--k-a1:#4C1D95;--k-a2:#7C3AED;
	--k-good:#16A34A;--k-warn:#B7791F;--k-bad:#D43F3B;--k-bolt:#D99A06;--k-direct:#0F9E8E;
	--k-shadow:0 1px 2px rgba(76,29,149,.06),0 10px 28px -16px rgba(76,29,149,.35);
	color-scheme:light;
}

/* ---------- sayfa zemini ve LuCI kabuğu ---------- */
html[data-kedi],html[data-kedi] body{background:var(--k-bg)!important;color:var(--k-ink)!important}
html[data-kedi] body .main,html[data-kedi] body .main-right,html[data-kedi] body #maincontent,
html[data-kedi] body #view,html[data-kedi] body .cbi-map,html[data-kedi] body .cbi-section,
html[data-kedi] body .cbi-section-node,html[data-kedi] body .cbi-tabcontainer{background:transparent!important;color:var(--k-ink)!important}
html[data-kedi] body header,html[data-kedi] body .main > header{background:var(--k-bg2)!important;border-bottom:1px solid var(--k-line);color:var(--k-ink)!important}
html[data-kedi] body header a,html[data-kedi] body .menu a{color:var(--k-soft)!important}
html[data-kedi] body header a:hover,html[data-kedi] body .menu a:hover{color:var(--k-ink)!important}
html[data-kedi] body header .brand{color:var(--k-ink)!important;font-weight:600;letter-spacing:.01em}
html[data-kedi] body #maincontent{font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;max-width:1240px}
html[data-kedi] body h1,html[data-kedi] body h2,html[data-kedi] body h3,html[data-kedi] body label,
html[data-kedi] body p,html[data-kedi] body td,html[data-kedi] body th,html[data-kedi] body legend{color:var(--k-ink)!important}
html[data-kedi] body a{color:var(--k-accent)}
html[data-kedi] body .main > footer,html[data-kedi] body footer{color:var(--k-mute)!important}
html[data-kedi] ::selection{background:var(--k-a2);color:#fff}

/* sayfa başlığı: logo + ad */
html[data-kedi] body #view > div > h2,html[data-kedi] body #view h2:first-child{
	display:flex;align-items:center;gap:12px;margin:6px 0 18px!important;font-size:1.7em;font-weight:700;letter-spacing:-.01em;color:var(--k-ink)!important;border:0}
html[data-kedi] body #view h2 img{height:1.55em!important;width:1.55em;margin:0!important;vertical-align:baseline!important;border-radius:11px!important;box-shadow:0 6px 18px -6px rgba(124,58,237,.7)}

/* üst sekmeler (Kontrol Paneli · Trafik · …) ve ayar sekmeleri */
html[data-kedi] body .tabs,html[data-kedi] body .cbi-tabmenu{background:transparent!important;border:0!important;border-bottom:1px solid var(--k-line)!important;display:flex;flex-wrap:wrap;gap:2px;margin:0 0 18px!important;padding:0!important}
html[data-kedi] body .tabs > li,html[data-kedi] body .cbi-tabmenu > li{background:transparent!important;border:0!important;margin:0!important;border-radius:0!important}
html[data-kedi] body .tabs > li > a,html[data-kedi] body .cbi-tabmenu > li > a{color:var(--k-soft)!important;background:transparent!important;border:0!important;border-radius:10px 10px 0 0;padding:9px 15px;font-weight:550;display:block}
html[data-kedi] body .tabs > li:hover > a,html[data-kedi] body .cbi-tabmenu > li:hover > a{color:var(--k-ink)!important;background:var(--k-card)!important}
html[data-kedi] body .tabs > li.active > a,html[data-kedi] body .cbi-tabmenu > li.cbi-tab > a,html[data-kedi] body .cbi-tabmenu > li.active > a{color:var(--k-ink)!important;box-shadow:inset 0 -3px 0 var(--k-bolt);background:var(--k-card)!important}
@media (max-width:700px){html[data-kedi] body .tabs,html[data-kedi] body .cbi-tabmenu{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}html[data-kedi] body .tabs > li > a,html[data-kedi] body .cbi-tabmenu > li > a{white-space:nowrap}}

/* ---------- kartlar ---------- */
html[data-kedi] .kr-card{background:var(--k-card)!important;border:1px solid var(--k-line)!important;border-top:1px solid var(--k-line)!important;border-radius:var(--k-r1);padding:18px 20px;box-shadow:var(--k-shadow);color:var(--k-ink)}
html[data-kedi] .kr-card:hover{box-shadow:var(--k-shadow);border-color:var(--k-line2)!important}
html[data-kedi] .kr-card h3{margin:0 0 12px;font-size:1.02em;font-weight:650;opacity:1;color:var(--k-ink)!important}
html[data-kedi] .kr-ch:hover{opacity:1}
html[data-kedi] .kr-caret{color:var(--k-accent);opacity:1}
html[data-kedi] .kr-grid{gap:16px;margin-bottom:16px}
html[data-kedi] .kr-grid > .kr-card:first-child{background:radial-gradient(120% 90% at 0 0,color-mix(in srgb,var(--k-a2) 26%,var(--k-card)),var(--k-card) 70%)!important}
html[data-kedi] .kr-sub,html[data-kedi] .kr-hint{color:var(--k-soft);opacity:1}
html[data-kedi] .kr-big{font-size:1.45em;font-weight:700;color:var(--k-ink)}
html[data-kedi] .kr-mono{background:var(--k-card2);color:var(--k-ink);border:1px solid var(--k-line);border-radius:7px}
html[data-kedi] .kr-app{border-bottom:1px solid var(--k-line)}
html[data-kedi] .kr-tag{background:color-mix(in srgb,var(--k-a2) 28%,transparent)!important;color:var(--k-accent);border-radius:999px;padding:1px 9px;font-weight:600}
html[data-kedi] .kr-tag.kr-tag-red{background:color-mix(in srgb,var(--k-bad) 24%,transparent)!important;color:var(--k-bad)}
html[data-kedi] .kr-active{background:color-mix(in srgb,var(--k-a2) 14%,transparent)!important}
html[data-kedi] .kr-warn{background:color-mix(in srgb,var(--k-warn) 14%,transparent);border-color:color-mix(in srgb,var(--k-warn) 45%,transparent);color:var(--k-ink);border-radius:var(--k-r3)}
html[data-kedi] .kr-errs{background:color-mix(in srgb,var(--k-bad) 12%,transparent);border-color:color-mix(in srgb,var(--k-bad) 45%,transparent);border-radius:var(--k-r3)}
html[data-kedi] .kr-ok{color:var(--k-good)}html[data-kedi] .kr-no{color:var(--k-bad)}
html[data-kedi] .kr-view,html[data-kedi] .kr-ed,html[data-kedi] .kr-gut{background:var(--k-in);border-color:var(--k-line);color:var(--k-ink)}
html[data-kedi] .kr-ed{border-radius:var(--k-r3)}

/* durum noktası */
html[data-kedi] .kr-dot{width:11px;height:11px}

/* ---------- düğmeler ---------- */
html[data-kedi] body .btn,html[data-kedi] body .cbi-button,html[data-kedi] body button.cbi-button{
	background:var(--k-card2)!important;color:var(--k-ink)!important;border:1px solid var(--k-line2)!important;border-radius:var(--k-r3)!important;
	box-shadow:none!important;text-shadow:none!important;min-height:34px;padding:6px 14px;font-weight:550;transition:background .18s,border-color .18s,transform .08s}
html[data-kedi] body .btn:hover,html[data-kedi] body .cbi-button:hover{background:color-mix(in srgb,var(--k-a2) 22%,var(--k-card2))!important;border-color:var(--k-accent)!important}
html[data-kedi] body .btn:active,html[data-kedi] body .cbi-button:active{transform:translateY(1px)}
html[data-kedi] body .cbi-button-action,html[data-kedi] body .btn.cbi-button-action,html[data-kedi] body button.cbi-button.cbi-button-action,html[data-kedi] body .cbi-page-actions .cbi-button-action,html[data-kedi] body .cbi-button-apply,html[data-kedi] body .btn.cbi-button-apply,html[data-kedi] body button.cbi-button.cbi-button-apply,html[data-kedi] body .cbi-page-actions .cbi-button-apply,html[data-kedi] body .cbi-button-save,html[data-kedi] body .btn.cbi-button-save,html[data-kedi] body button.cbi-button.cbi-button-save,html[data-kedi] body .cbi-page-actions .cbi-button-save,html[data-kedi] body .cbi-button-positive,html[data-kedi] body .btn.cbi-button-positive,html[data-kedi] body button.cbi-button.cbi-button-positive,html[data-kedi] body .cbi-page-actions .cbi-button-positive{
	background:linear-gradient(135deg,var(--k-a1),var(--k-a2))!important;color:#fff!important;border-color:transparent!important}
html[data-kedi] body .cbi-button-action:hover,html[data-kedi] body .btn.cbi-button-action:hover,html[data-kedi] body button.cbi-button.cbi-button-action:hover,html[data-kedi] body .cbi-page-actions .cbi-button-action:hover,html[data-kedi] body .cbi-button-apply:hover,html[data-kedi] body .btn.cbi-button-apply:hover,html[data-kedi] body button.cbi-button.cbi-button-apply:hover,html[data-kedi] body .cbi-page-actions .cbi-button-apply:hover,html[data-kedi] body .cbi-button-save:hover,html[data-kedi] body .btn.cbi-button-save:hover,html[data-kedi] body button.cbi-button.cbi-button-save:hover,html[data-kedi] body .cbi-page-actions .cbi-button-save:hover,html[data-kedi] body .cbi-button-positive:hover,html[data-kedi] body .btn.cbi-button-positive:hover,html[data-kedi] body button.cbi-button.cbi-button-positive:hover,html[data-kedi] body .cbi-page-actions .cbi-button-positive:hover{filter:brightness(1.12);background:linear-gradient(135deg,var(--k-a1),var(--k-a2))!important}
html[data-kedi] body .cbi-button-negative,html[data-kedi] body .cbi-button-remove{color:var(--k-bad)!important;border-color:color-mix(in srgb,var(--k-bad) 55%,transparent)!important;background:transparent!important}
html[data-kedi] body .cbi-button-negative:hover{background:color-mix(in srgb,var(--k-bad) 16%,transparent)!important}
html[data-kedi] body .btn[disabled],html[data-kedi] body .cbi-button[disabled]{opacity:.45}
html[data-kedi] body :focus-visible{outline:2px solid var(--k-bolt);outline-offset:2px}

/* VPN | Direkt | Engelle seçici */
html[data-kedi] .kr-seg{border:1px solid var(--k-line2);border-radius:999px;background:var(--k-in);padding:2px;gap:2px}
html[data-kedi] .kr-seg button{border-radius:999px!important;padding:5px 15px;color:var(--k-soft)!important;background:transparent!important;border:0!important;min-height:0}
html[data-kedi] .kr-seg button:not(.kr-act):hover{background:var(--k-card2)!important;color:var(--k-ink)!important}
html[data-kedi] .kr-seg button.kr-act{background:linear-gradient(135deg,var(--k-a1),var(--k-a2))!important;color:#fff!important;animation:none}
html[data-kedi] .kr-seg button.kr-act.kr-direct{background:linear-gradient(135deg,#0F766E,#14B8A6)!important;color:#fff!important}
html[data-kedi] .kr-seg button.kr-act.kr-block{background:linear-gradient(135deg,#9F1239,#E11D48)!important;color:#fff!important}
html[data-kedi] .kr-seg button.kr-blockbtn{color:var(--k-bad)!important}
html[data-kedi] .kr-seg:has(button.kr-act){animation:none}
html[data-kedi] .kr-seg.kr-dim{opacity:.45}
html[data-kedi] .kr-seg.kr-dim button.kr-act{background:transparent!important;color:var(--k-soft)!important}
/* sekmeler (sunucu ekle penceresi vb.) */
html[data-kedi] .kr-tabs button{border:1px solid var(--k-line2);color:var(--k-soft);background:transparent;border-radius:999px;padding:5px 16px}
html[data-kedi] .kr-tabs button.kr-act{background:linear-gradient(135deg,var(--k-a1),var(--k-a2))!important;border-color:transparent!important;color:#fff!important}

/* anahtar */
html[data-kedi] .kr-switch span.kr-knob{background:var(--k-line2)}
html[data-kedi] .kr-switch input:checked + span.kr-knob{background:var(--k-a2)}
html[data-kedi] .kr-switch span.kr-knob:after{box-shadow:0 1px 3px rgba(0,0,0,.4)}

/* ---------- form alanları ---------- */
html[data-kedi] body input:not([type=checkbox]):not([type=radio]),html[data-kedi] body select,html[data-kedi] body textarea,html[data-kedi] body .cbi-dropdown{
	background:var(--k-in)!important;color:var(--k-ink)!important;border:1px solid var(--k-line2)!important;border-radius:var(--k-r3)!important;box-shadow:none!important;min-height:34px}
html[data-kedi] body input:focus,html[data-kedi] body select:focus,html[data-kedi] body textarea:focus{border-color:var(--k-accent)!important;box-shadow:0 0 0 3px color-mix(in srgb,var(--k-a2) 30%,transparent)!important}
html[data-kedi] body input[type=checkbox],html[data-kedi] body input[type=radio]{accent-color:var(--k-a2)}
html[data-kedi] body .cbi-dropdown > ul,html[data-kedi] body .cbi-dropdown > ul > li{background:var(--k-card)!important;color:var(--k-ink)!important}
html[data-kedi] body .cbi-dropdown > ul > li[selected],html[data-kedi] body .cbi-dropdown > ul > li:hover{background:var(--k-card2)!important}
html[data-kedi] body .cbi-value-description,html[data-kedi] body .cbi-section-descr,html[data-kedi] body .cbi-value-helptext{color:var(--k-soft)!important}
html[data-kedi] body .cbi-value{border-bottom:1px solid var(--k-line)}
html[data-kedi] body .cbi-section{background:var(--k-card)!important;border:1px solid var(--k-line);border-radius:var(--k-r1);padding:14px 20px;margin-bottom:16px;box-shadow:var(--k-shadow)}
html[data-kedi] body .cbi-section h3{border-bottom:1px solid var(--k-line)}

/* ---------- tablolar ---------- */
html[data-kedi] body .table,html[data-kedi] body table{border-color:var(--k-line)!important}
html[data-kedi] body .table .tr,html[data-kedi] body .table .td,html[data-kedi] body .table .th,html[data-kedi] body .cbi-section-table-row,html[data-kedi] body table tr{background:transparent!important;border-color:var(--k-line)!important}
html[data-kedi] body .table .th,html[data-kedi] body table th{color:var(--k-soft)!important;font-size:.82em;font-weight:600;letter-spacing:.02em;border-bottom:1px solid var(--k-line2)!important}
html[data-kedi] body table.kr-table tr:hover td,html[data-kedi] body .table .tr:hover .td{background:color-mix(in srgb,var(--k-a2) 8%,transparent)!important}
html[data-kedi] .kr-table td,html[data-kedi] .kr-table th{padding:9px 10px!important}

/* ---------- pencereler ---------- */
html[data-kedi] body .modal{background:var(--k-card)!important;color:var(--k-ink)!important;border:1px solid var(--k-line2);border-radius:var(--k-r1);box-shadow:0 30px 80px -20px rgba(0,0,0,.7)}
html[data-kedi] body #modal_overlay{background:rgba(10,6,20,.62)!important;backdrop-filter:blur(3px)}
html[data-kedi] body .modal h4{color:var(--k-ink)!important}

/* genel LuCI parçaları */
html[data-kedi] body .alert-message{border-radius:var(--k-r2);border:1px solid var(--k-line2);background:var(--k-card)!important;color:var(--k-ink)}
html[data-kedi] body .cbi-progressbar{border-radius:999px;border-color:var(--k-line2);background:var(--k-in)}
html[data-kedi] body .cbi-progressbar > div{background:linear-gradient(90deg,var(--k-a1),var(--k-a2))!important;border-radius:999px}
html[data-kedi] body .ifacebox,html[data-kedi] body .ifacebadge{background:var(--k-card)!important;border:1px solid var(--k-line)!important;border-radius:var(--k-r2);color:var(--k-ink)}
html[data-kedi] body .label{border-radius:999px}
html[data-kedi] body pre,html[data-kedi] body code,html[data-kedi] body .cbi-tooltip{background:var(--k-card2);color:var(--k-ink);border-radius:var(--k-r3);border:1px solid var(--k-line)}
html[data-kedi] body .cbi-section-error{border-radius:var(--k-r3)}
html[data-kedi] body .spinning{color:var(--k-soft)}
html[data-kedi] body #indicators .label{background:color-mix(in srgb,var(--k-a2) 30%,transparent);color:var(--k-ink)!important}
html[data-kedi] body .cbi-page-actions{background:transparent!important;border:0!important;padding:8px 0!important}
html[data-kedi] body header ul .active > a,html[data-kedi] body header .nav .active > a,html[data-kedi] body header .brand:hover{background:color-mix(in srgb,var(--k-a2) 24%,transparent)!important;color:var(--k-ink)!important;box-shadow:inset 0 -3px 0 var(--k-bolt)}
html[data-kedi] body .nav .dropdown-menu{background:var(--k-card)!important;border:1px solid var(--k-line2);border-radius:var(--k-r3);box-shadow:var(--k-shadow)}
html[data-kedi] body .nav .dropdown-menu a{color:var(--k-ink)!important}
html[data-kedi] body .nav .dropdown-menu a:hover,html[data-kedi] body .nav .dropdown-menu .active a{background:color-mix(in srgb,var(--k-a2) 22%,transparent)!important}
KT_EOF_3
put "$ROOT/www/luci-static/kedi/logo.svg" 644 <<'KT_EOF_4'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" width="256" height="256">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#4C1D95"/>
      <stop offset="1" stop-color="#7C3AED"/>
    </linearGradient>
  </defs>
  <rect width="108" height="108" rx="26" fill="url(#bg)"/>
  <path fill="#F3E8FF" d="M30,32 L43,43 Q54,40 65,43 L78,32 L78,62 Q78,80 54,80 Q30,80 30,62 Z"/>
  <path fill="#C4B5FD" d="M34,38 L41,44 L34,50 Z M74,38 L67,44 L74,50 Z"/>
  <path fill="#FBBF24" d="M57,40 L47,56 L53,56 L50,67 L61,50 L55,50 Z"/>
  <path fill="#4C1D95" d="M37,62 Q41,57 45,62 Q41,66 37,62 Z M63,62 Q67,57 71,62 Q67,66 63,62 Z"/>
  <path fill="#A78BFA" d="M51,69 L57,69 L54,73 Z"/>
</svg>
KT_EOF_4
base64 -d <<'KT_EOF_5' | put "$ROOT/www/luci-static/kedi/logo_48.png" 644
iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAC8ElEQVR4nOyazWsTQRjGn91sXLSt
NdqiFWksVvBU7MUvpE2h0l5VBBHRJsYe/QeUWosePDfnbGtEPQgVP45qUDFBvIhVK6KkpVhtFfph
k+4mu+PMplkTG6UH4TWwPzLLTHY2vM+8H7MbVonH4wwVjCIOgUBAQgUiFl8pDGKx2Ko9oev6lXA4
PMC7BohxBDBu/sH2Tmyq3/yX6QyJZ48xOZE6H41G/aFQKMy/1EFIkQCGRZ2BzZswrT9M9jDoWYaW
lhb4fBtPatpQYzDY08VPLYEIudBhzIKRY0gbDD+WLKzh0nY2KGis89hj0TK8mWY+0pqbd6C7u6tN
07QxPlwHIhwPWBYD/9ie2LJBRoMvf0r1SmhtWoPRCR3CdNM0kUgk7CaQJMkfjWqLoVCQpBCUhJDA
X+/F+rUrbbF4WOVyObTu7UBbRye8HokbzxMgk8aDu7dBRZEHLDuTP30xeCiZZSfL3OIFEUo8D2Ru
vIcfZJ4w9rVElHjAWm6mVb6iCllZ89c5xSNDlZjjPQpKPMCWc4BZqzOIyQxqVU2qt/dsE4j4TQCz
Y70QEVwKTJbFfHaKlysF1UodFFl1LjYMK75rq9IBQkpCSKy7ECIqzUJ2Gu/nH+LFzDBkbz6paz3b
0Oo7hqbqA1DlmqHA7togiHH2AdsD+TzGVGYMye8aXs5ec4wXzJmTePotgtj4qf6C8ZFIxD84GCFL
gqKNTNjAMKN/wOu5EXxcjJe9gG93PdcPP7ok+u+mWPv+QydSlElc5AG+AxuzGJ29h/F0suxk7ovA
zSPJYdE/d//M6TtjV+N25bL+gyokbiWSX29hUn7DE3flTabMpO03jj4fF/3jI/suThtv+zNsGk8+
i5+QQYUjIJPJQH5VhUbsKZnAFzjV13fBKZMDA5c1aRQ9hXFaWoKqqqBCEg8FlfxAQ+f7f4QrgBpX
ADWuAGpcAdS4AqhxBVDjCqDGFUCNK4AaVwA1rgBqXAHUuAKoqXgB9r/TlfzKzU8AAAD//yluJkgA
AAAGSURBVAMAONFUkVZp36UAAAAASUVORK5CYII=
KT_EOF_5
put "$ROOT/www/luci-static/resources/menu-kedi.js" 644 <<'KT_EOF_6'
'use strict';
'require baseclass';
'require ui';

return baseclass.extend({
	__init__() {
		ui.menu.load().then((tree) => this.render(tree));
	},

	render(tree) {
		let node = tree;
		let url = '';

		this.renderModeMenu(tree);

		if (L.env.dispatchpath.length >= 3) {
			for (var i = 0; i < 3 && node; i++) {
				node = node.children[L.env.dispatchpath[i]];
				url = url + (url ? '/' : '') + L.env.dispatchpath[i];
			}

			if (node)
				this.renderTabMenu(node, url);
		}
	},

	renderTabMenu(tree, url, level) {
		const container = document.querySelector('#tabmenu');
		const ul = E('ul', { 'class': 'tabs' });
		const children = ui.menu.getChildren(tree);
		let activeNode = null;

		children.forEach(child => {
			const isActive = (L.env.dispatchpath[3 + (level || 0)] == child.name);
			const activeClass = isActive ? ' active' : '';
			const className = 'tabmenu-item-%s %s'.format(child.name, activeClass);

			ul.appendChild(E('li', { 'class': className }, [
				E('a', { 'href': L.url(url, child.name) }, [ _(child.title) ] )]));

			if (isActive)
				activeNode = child;
		});

		if (ul.children.length == 0)
			return E([]);

		container.appendChild(ul);
		container.style.display = '';

		if (activeNode)
			this.renderTabMenu(activeNode, url + '/' + activeNode.name, (level || 0) + 1);

		return ul;
	},

	renderMainMenu(tree, url, level) {
		const ul = level ? E('ul', { 'class': 'dropdown-menu' }) : document.querySelector('#topmenu');
		const children = ui.menu.getChildren(tree);

		if (children.length == 0 || level > 1)
			return E([]);

		children.forEach(child => {
			const submenu = this.renderMainMenu(child, url + '/' + child.name, (level || 0) + 1);
			const subclass = (!level && submenu.firstElementChild) ? 'dropdown' : '';
			const linkclass = (!level && submenu.firstElementChild) ? 'menu' : '';
			const linkurl = submenu.firstElementChild ? '#' : L.url(url, child.name);

			const li = E('li', { 'class': subclass }, [
				E('a', { 'class': linkclass, 'href': linkurl }, [
					_(child.title),
				]),
				submenu
			]);

			ul.appendChild(li);
		});

		ul.style.display = '';

		return ul;
	},

	renderModeMenu(tree) {
		const ul = document.querySelector('#modemenu');
		const children = ui.menu.getChildren(tree);

		children.forEach((child, index) => {
			const isActive = L.env.requestpath.length
				? child.name === L.env.requestpath[0]
				: index === 0;

			ul.appendChild(E('li', { 'class': isActive ? 'active' : '' }, [
				E('a', { 'href': L.url(child.name) }, [ _(child.title) ])
			]));

			if (isActive)
				this.renderMainMenu(child, child.name);
		});

		if (ul.children.length > 1)
			ul.style.display = '';
	}
});
KT_EOF_6
put "$ROOT/www/luci-static/resources/view/kedi/sysauth.js" 644 <<'KT_EOF_7'
'use strict';
'require ui';
'require view';

return view.extend({
	render() {
		const form = document.querySelector('form');
		const btn = document.querySelector('button');

		const dlg = ui.showModal(
			_('Authorization Required'),
			Array.from(document.querySelectorAll('section > *')),
			'login'
		);

		form.addEventListener('keypress', (ev) => {
			if (ev.key === 'Enter')
				btn.click();
		});

		btn.addEventListener('click', () => {
			dlg.querySelectorAll('*').forEach((node) => {
				node.style.display = 'none';
			});
			dlg.appendChild(E('div', {
				class: 'spinning'
			}, _('Logging in…')));

			form.submit();
		});

		document.querySelector('input[type="password"]').focus();

		return '';
	},

	addFooter() {},

});
KT_EOF_7
put "$ROOT$TPL/kedi/header.ut" 644 <<'KT_EOF_8'
{#
 Copyright 2008 Steven Barth <steven@midlink.org>
 Copyright 2012 David Menting <david@nut-bolt.nl>
 Copyright 2008-2022 Jo-Philipp Wich <jo@mein.io>
 Licensed to the public under the Apache License 2.0.
-#}

{%
	import { getuid, getspnam } from 'luci.core';

	const boardinfo = ubus.call('system', 'board') ?? {};
	const darkpref = null;

	http.prepare_content('text/html; charset=UTF-8');
-%}

<!DOCTYPE html>
<html lang="{{ dispatcher.lang }}" {{ darkpref ? `data-darkmode="${darkpref}"` : '' }}>
	<head>
		<meta charset="utf-8">
		<title>{{ striptags(`${boardinfo.hostname ?? '?'}${dispatched?.title ? ` | ${_(dispatched.title)}` : ''}`) }}</title>
		<script>
			/* Kedi teması: koyu / açık / otomatik (KediRay'daki seçimle ortak: localStorage "kediray-theme") */
			(function () {
				var r = document.documentElement, mq = window.matchMedia('(prefers-color-scheme: dark)');
				function apply() {
					var m = 'auto';
					try { m = (JSON.parse(localStorage.getItem('kediray-theme') || '{}') || {}).mode || 'auto'; } catch (e) {}
					var dark = m === 'dark' ? true : (m === 'light' ? false : mq.matches);
					r.setAttribute('data-darkmode', dark);
					r.setAttribute('data-kedi', dark ? 'dark' : 'light');
				}
				mq.addEventListener('change', apply);
				apply();
			})();
		</script>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="darkreader-lock">
		<link rel="stylesheet" href="{{ media }}/cascade.css">
		<link rel="stylesheet" href="{{ media }}/kedi.css">
		<link rel="stylesheet" media="only screen and (max-device-width: 854px)" href="{{ media }}/mobile.css" />
		<link rel="icon" href="{{ media }}/logo_48.png" sizes="48x48">
		<link rel="icon" href="{{ media }}/logo.svg" sizes="any">
		{% if (dispatched?.css): %}
		<link rel="stylesheet" href="{{ resource }}/{{ dispatched.css }}">
		{% endif %}
		{% if (css): %}
		<style title="text/css">{{ css }}</style>
		{% endif %}
		<script src="{{ dispatcher.build_url('admin/translations', dispatcher.lang) }}"></script>
		<script src="{{ resource }}/cbi.js"></script>
	</head>

	<body class="lang_{{ dispatcher.lang }}" data-page="{{ entityencode(join('-', length(ctx.request_path) ? ctx.request_path : ctx.path), true) }}">
		{% if (!blank_page): %}
		<header>
			<a class="brand" href="/">{{ striptags(boardinfo.hostname ?? '?') }}</a>
			<ul class="nav" id="topmenu" style="display:none"></ul>
			<div id="indicators" class="pull-right"></div>
		</header>

		<div id="maincontent" class="container">
			{% if (getuid() == 0 && getspnam('root')?.pwdp === ''): %}
				<div class="alert-message warning">
					<h4>{{ _('No password set!') }}</h4>
					<p>{{ _('There is no password set on this router. Please configure a root password to protect the web interface.') }}</p>
					{% if (dispatcher.lookup("admin/system/admin")): %}
					  <div class="right"><a class="btn" href="{{ dispatcher.build_url("admin/system/admin") }}">{{ _('Go to password configuration...') }}</a></div>
					{% endif %}
				</div>
			{% endif %}

			{% if (boardinfo.rootfs_type == "initramfs"): %}
				<div class="alert-message warning">
					<h4>{{ _('System running in recovery (initramfs) mode.') }}</h4>
					<p>{{ _('No changes to settings will be stored and are lost after rebooting. This mode should only be used to install a firmware upgrade') }}</p>
					{% if (dispatcher.lookup("admin/system/flash")): %}
					  <div class="right"><a class="btn" href="{{ dispatcher.build_url("admin/system/flash") }}">{{ _('Go to firmware upgrade...') }}</a></div>
					{% endif %}
				</div>
			{% endif %}

			<noscript>
				<div class="alert-message warning">
					<h4>{{ _('JavaScript required!') }}</h4>
					<p>{{ _('You must enable JavaScript in your browser or LuCI will not work properly.') }}</p>
				</div>
			</noscript>

			<div id="tabmenu" style="display:none"></div>
		{% endif %}
KT_EOF_8
put "$ROOT$TPL/kedi/footer.ut" 644 <<'KT_EOF_9'
		{% if (!blank_page): %}
		</div>
		<footer>
			<span>
				Powered by
				<a href="https://github.com/openwrt/luci" target="_blank" rel="noreferrer">
					{{ version.luciname }} ({{ version.luciversion }})</a>
				/
				<a href="{{ entityencode(version.disturl ?? '#', true) }}" target="_blank" rel="noreferrer">
					{{ version.distname }} {{ version.distversion }} ({{ version.distrevision }})</a>
				{% if (lua_active): %}
					/ {{ _('Lua compatibility mode active') }}
				{% endif %}
			</span>
			<ul class="breadcrumb pull-right" id="modemenu" style="display:none"></ul>
		</footer>
		<script>L.require('menu-kedi')</script>
		{% endif %}
	</body>
</html>
KT_EOF_9
put "$ROOT$TPL/kedi/sysauth.ut" 644 <<'KT_EOF_10'
{#
 Copyright 2022 Jo-Philipp Wich <jo@mein.io>
 Licensed to the public under the Apache License 2.0.
-#}

{% include('header', { blank_page: true }) %}

<section hidden>
	<form method="post" class="cbi-map">
		<div class="cbi-section">
			<div class="cbi-section-node">
				<div class="cbi-value">
					<label class="cbi-value-title" for="luci_username">{{ _('Username') }}</label>
					<div class="cbi-value-field">
						<input name="luci_username" id="luci_username" type="text" autocomplete="username" value="{{ entityencode(duser, true) }}">
					</div>
				</div>
				<div class="cbi-value">
					<label class="cbi-value-title" for="luci_password">{{ _('Password') }}</label>
					<div class="cbi-value-field">
						<input name="luci_password" id="luci_password" type="password" autocomplete="current-password">
					</div>
				</div>
				{% if (auth_fields): %}
					{% for (let field in auth_fields): %}
						<div class="cbi-value">
							<label class="cbi-value-title" for="{{ field.name }}">{{ _(field.label ?? field.name) }}</label>
							<div class="cbi-value-field">
								<input
									name="{{ field.name }}"
									id="{{ field.name }}"
									type="{{ field.type ?? 'text' }}"
									{% if (field.placeholder): %}placeholder="{{ field.placeholder }}"{% endif %}
									{% if (field.inputmode): %}inputmode="{{ field.inputmode }}"{% endif %}
									{% if (field.pattern): %}pattern="{{ field.pattern }}"{% endif %}
									{% if (field.maxlength): %}maxlength="{{ field.maxlength }}"{% endif %}
									{% if (field.autocomplete): %}autocomplete="{{ field.autocomplete }}"{% endif %}
									{% if (field.required): %}required{% endif %}
								>
							</div>
						</div>
					{% endfor %}
				{% endif %}
				{% if (auth_html): %}
					<div class="cbi-value">
						{{ auth_html }}
					</div>
				{% endif %}
				{% if (auth_assets): %}
					{% for (let asset in auth_assets): %}
						{% if (asset.type == 'script'): %}
							<script src="{{ asset.src }}"></script>
						{% endif %}
					{% endfor %}
				{% endif %}
			</div>
		</div>
	</form>

	<hr>

	{% if (auth_message): %}
	<div class="alert-message{% if (auth_plugin): %} warning{% endif %}">
		{{ auth_message }}
	</div>
	{% elif (fuser): %}
	<div class="alert-message error">
		{{ _('Invalid username and/or password! Please try again.') }}
	</div>
	{% endif %}

	<button class="btn cbi-button-positive important">{{ _('Log in') }}</button>
</section>

<div id="view">
	<div class="spinning">{{ _('Loading view…') }}</div>
	<script>
		L.require('ui').then(function(ui) {
			ui.instantiateView('kedi.sysauth');
		});
	</script>
</div>

{% include('footer', { blank_page: true }) %}
KT_EOF_10

if [ -z "$ROOT" ] && command -v uci >/dev/null 2>&1; then
	uci set luci.themes.Kedi=/luci-static/kedi
	if [ "$MODE" = install ]; then
		cur=$(uci -q get luci.main.mediaurlbase)
		[ "$cur" != /luci-static/kedi ] && [ -n "$cur" ] && echo "$cur" > /etc/luci-theme-kedi.prev
		uci set luci.main.mediaurlbase=/luci-static/kedi
	fi
	uci commit luci
	clear_cache
fi
echo "luci-theme-kedi $KT_VERSION kuruldu."
[ "$MODE" = install ] && echo "Tema etkin. Tarayıcıda sayfayı yenile (Ctrl+Shift+R). Geri almak için: sh $0 --remove"
[ "$MODE" = noact ] && echo "Etkinleştirmek için: Sistem → Görünüm → Tema: Kedi"
exit 0
